/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import config.HibernateUtil;
import hibclass.Autobus;
import hibclass.Glinija;
import hibclass.Gstanica;
import hibclass.Kartica;
import hibclass.Korisnik;
import hibclass.Mlinija;
import hibclass.Prevoznik;
import hibclass.Rezervacija;
import hibclass.Slika;
import hibclass.Stajaliste;
import hibclass.Vozac;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

/**
 *
 * @author User
 */
@Named(value = "con2")
@SessionScoped

public class ControlerAdmin implements Serializable {

    private Glinija g = new Glinija();
    private Gstanica gs = new Gstanica();
    private Vozac v = new Vozac();
    private String medjustanice = "";
    private ArrayList<Vozac> listaVozaca = new ArrayList<>();
    private ArrayList<String> listaIzabranihVozaca = new ArrayList<>();
    private String messagedg;
    private ArrayList<Glinija> glista = new ArrayList<>();
    private ArrayList<Glinija> filteglista;
    private Date datum1;
    private Date datum2;
    private String motkaz;
    private ArrayList<Korisnik> reglista = new ArrayList<>();
    private ArrayList<Korisnik> filterreglista;
    private String messagereg = "";
    private ArrayList<Rezervacija> rlista = new ArrayList<>();
    private ArrayList<Rezervacija> filterrlista;
    private String messagerez = "";
    private ArrayList<Kartica> klista = new ArrayList<>();
    private ArrayList<Kartica> filterklista;
    private String messagek = "";
    private String mgmessage = "";
    private Prevoznik prev = new Prevoznik();
    private UploadedFile uploadedFile;
    private String prevmessage;
    private ArrayList<Prevoznik> filterplista;
    private Vozac vozac = new Vozac();
    private String messagevoz;
    private Autobus bus = new Autobus();
    private String messagebus;
    private Slika s = new Slika();
    private ArrayList<UploadedFile> fajllist = new ArrayList<>();
    private int id = 0;
    private ArrayList<Mlinija> listam = new ArrayList<>();
    private ArrayList<Mlinija> filterliistam;
    

    private int indeks = 0;
    private Mlinija nova = new Mlinija();
    private ArrayList<Autobus> alista = new ArrayList<>();
    private ArrayList<Prevoznik> plista = new ArrayList<>();
    private ArrayList<Vozac> listavoz = new ArrayList<>();
    private ArrayList<Vozac> filtervoz;

    public ControlerAdmin() {
    }

    public ArrayList<Vozac> getFiltervoz() {
        return filtervoz;
    }

    public void setFiltervoz(ArrayList<Vozac> filtervoz) {
        this.filtervoz = filtervoz;
    }

 

    public ArrayList<Mlinija> getFilterliistam() {
        return filterliistam;
    }

    public void setFilterliistam(ArrayList<Mlinija> filterliistam) {
        this.filterliistam = filterliistam;
    }
    
    

    public ArrayList<Mlinija> getListam() {
        return listam;
    }

    public void setListam(ArrayList<Mlinija> listam) {
        this.listam = listam;
    }
    
    

    public ArrayList<UploadedFile> getFajllist() {
        return fajllist;
    }

    public void setFajllist(ArrayList<UploadedFile> fajllist) {
        this.fajllist = fajllist;
    }

    public Slika getS() {
        return s;
    }

    public void setS(Slika s) {
        this.s = s;
    }

    public String getMessagebus() {
        return messagebus;
    }

    public void setMessagebus(String messagebus) {
        this.messagebus = messagebus;
    }

    public Autobus getBus() {
        return bus;
    }

    public void setBus(Autobus bus) {
        this.bus = bus;
    }

    public String getMessagevoz() {
        return messagevoz;
    }

    public void setMessagevoz(String messagevoz) {
        this.messagevoz = messagevoz;
    }

    public Vozac getVozac() {
        return vozac;
    }

    public void setVozac(Vozac vozac) {
        this.vozac = vozac;
    }

    public ArrayList<Prevoznik> getFilterplista() {
        return filterplista;
    }

    public void setFilterplista(ArrayList<Prevoznik> filterplista) {
        this.filterplista = filterplista;
    }

    public String getPrevmessage() {
        return prevmessage;
    }

    public void setPrevmessage(String prevmessage) {
        this.prevmessage = prevmessage;
    }

    public UploadedFile getUploadedFile() {
        return uploadedFile;
    }

    public void setUploadedFile(UploadedFile uploadedFile) {
        this.uploadedFile = uploadedFile;
    }

    public Prevoznik getPrev() {
        return prev;
    }

    public void setPrev(Prevoznik prev) {
        this.prev = prev;
    }

    public String getMgmessage() {
        return mgmessage;
    }

    public void setMgmessage(String mgmessage) {
        this.mgmessage = mgmessage;
    }

    public ArrayList<Vozac> getListavoz() {
        return listavoz;
    }

    public void setListavoz(ArrayList<Vozac> listavoz) {
        this.listavoz = listavoz;
    }

    public ArrayList<Prevoznik> getPlista() {
        return plista;
    }

    public void setPlista(ArrayList<Prevoznik> plista) {
        this.plista = plista;
    }

    public ArrayList<Autobus> getAlista() {
        return alista;
    }

    public void setAlista(ArrayList<Autobus> alista) {
        this.alista = alista;
    }

    public Mlinija getNova() {
        return nova;
    }

    public void setNova(Mlinija nova) {
        this.nova = nova;
    }

    public int getIndeks() {
        return indeks;
    }

    public void setIndeks(int indeks) {
        this.indeks = indeks;
    }

    public String getMessagek() {
        return messagek;
    }

    public void setMessagek(String messagek) {
        this.messagek = messagek;
    }

    public ArrayList<Kartica> getKlista() {
        return klista;
    }

    public void setKlista(ArrayList<Kartica> klista) {
        this.klista = klista;
    }

    public ArrayList<Kartica> getFilterklista() {
        return filterklista;
    }

    public void setFilterklista(ArrayList<Kartica> filterklista) {
        this.filterklista = filterklista;
    }

    public String getMessagerez() {
        return messagerez;
    }

    public void setMessagerez(String messagerez) {
        this.messagerez = messagerez;
    }

    public ArrayList<Rezervacija> getFilterrlista() {
        return filterrlista;
    }

    public void setFilterrlista(ArrayList<Rezervacija> filterrlista) {
        this.filterrlista = filterrlista;
    }

    public ArrayList<Rezervacija> getRlista() {
        return rlista;
    }

    public void setRlista(ArrayList<Rezervacija> rlista) {
        this.rlista = rlista;
    }

    public String getMessagereg() {
        return messagereg;
    }

    public void setMessagereg(String messagereg) {
        this.messagereg = messagereg;
    }

    public ArrayList<Korisnik> getFilterreglista() {
        return filterreglista;
    }

    public void setFilterreglista(ArrayList<Korisnik> filterreglista) {
        this.filterreglista = filterreglista;
    }

    public ArrayList<Korisnik> getReglista() {
        return reglista;
    }

    public void setReglista(ArrayList<Korisnik> reglista) {
        this.reglista = reglista;
    }

    public String getMotkaz() {
        return motkaz;
    }

    public void setMotkaz(String motkaz) {
        this.motkaz = motkaz;
    }

    public Date getDatum2() {
        return datum2;
    }

    public void setDatum2(Date datum2) {
        this.datum2 = datum2;
    }

    public Date getDatum1() {
        return datum1;
    }

    public void setDatum1(Date datum1) {
        this.datum1 = datum1;
    }

    public ArrayList<Glinija> getFilteglista() {
        return filteglista;
    }

    public void setFilteglista(ArrayList<Glinija> filteglista) {
        this.filteglista = filteglista;
    }

    public ArrayList<Glinija> getGlista() {
        return glista;
    }

    public void setGlista(ArrayList<Glinija> glista) {
        this.glista = glista;
    }

    public String getMessagedg() {
        return messagedg;
    }

    public void setMessagedg(String messagedg) {
        this.messagedg = messagedg;
    }

    public ArrayList<Vozac> getListaVozaca() {
        return listaVozaca;
    }

    public void setListaVozaca(ArrayList<Vozac> listaVozaca) {
        this.listaVozaca = listaVozaca;
    }

    public ArrayList<String> getListaIzabranihVozaca() {
        return listaIzabranihVozaca;
    }

    public void setListaIzabranihVozaca(ArrayList<String> listaIzabranihVozaca) {
        this.listaIzabranihVozaca = listaIzabranihVozaca;
    }

    public String getMedjustanice() {
        return medjustanice;
    }

    public void setMedjustanice(String medjustanice) {
        this.medjustanice = medjustanice;
    }

    public Glinija getG() {
        return g;
    }

    public void setG(Glinija g) {
        this.g = g;
    }

    public Gstanica getGs() {
        return gs;
    }

    public void setGs(Gstanica gs) {
        this.gs = gs;
    }

    public Vozac getV() {
        return v;
    }

    public void setV(Vozac v) {
        this.v = v;
    }

    public String otkazigrad() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "select * from glinija";
        SQLQuery sql = sesija.createSQLQuery(upit);
        glista = new ArrayList<>();
        List<Object[]> rs = sql.list();
        for (int i = 0; i < rs.size(); i++) {
            Object[] tmp = rs.get(i);
            Glinija g = new Glinija();
            g.setPocetnoOdrediste(tmp[0].toString());
            g.setKrajnjeOdrediste(tmp[1].toString());
            g.setBrojLinije(tmp[2].toString());
            g.setRedVoznje(tmp[3].toString());
            glista.add(g);

        }
        sesija.close();
        return "otkazigrad";
    }

    public String otkazi(Glinija i) {
        i.setFlag(true);
        return null;
    }

    public String potvrdi(Glinija i) {
        i.setFlag(false);
        String poruka = "Linija " + i.getBrojLinije() + " je otkazana za period od " + datum1 + " do " + datum2 + " !";
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "insert into poruka(uname,sadrzaj) values (?,?)";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, "admin");
        sql.setString(1, poruka);
        sql.executeUpdate();
        sesija.getTransaction().commit();
        motkaz = "Uspesno otkazana linija " + i.getBrojLinije() + " !";
        return null;
    }

    public String gradske() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "select * from vozac";
        SQLQuery sql = sesija.createSQLQuery(upit);
        listaVozaca = new ArrayList<>();
        List<Object[]> rs = sql.list();
        for (int i = 0; i < rs.size(); i++) {
            Object[] tmp = rs.get(i);
            Vozac v = new Vozac();
            v.setId((Integer) tmp[0]);
            v.setIme(tmp[1].toString());
            v.setPrezime(tmp[2].toString());
            v.setDatumRodjenja((Date) tmp[3]);
            v.setGodinaPocetka((Integer) tmp[4]);
            listaVozaca.add(v);
        }
        sesija.close();
        return "dodajgradske";
    }

    public String dodajvozaca() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "insert into vozac(ime,prezime,datumRodjenja,godinaPocetka) values (?,?,?,?)";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, v.getIme());
        sql.setString(1, v.getPrezime());
        sql.setDate(2, v.getDatumRodjenja());
        sql.setInteger(3, v.getGodinaPocetka());
        sql.executeUpdate();
        sesija.getTransaction().commit();
        v = new Vozac();
        sesija.close();
        messagedg = "Uspesno dodat vozac!";
        return null;
    }

    public String dodajgradske() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "insert into glinija values(?,?,?,?)";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, g.getPocetnoOdrediste());
        sql.setString(1, g.getKrajnjeOdrediste());
        sql.setString(2, g.getBrojLinije());
        sql.setString(3, g.getRedVoznje());
        sql.executeUpdate();
        //  sesija.getTransaction().commit();

        String[] stanice = medjustanice.split("-");
        for (int i = 0; i < stanice.length; i++) {
            String m = stanice[i];
            String upit1 = "insert into gstanica values(?,?,?)";
            SQLQuery sql1 = sesija.createSQLQuery(upit1);
            sql1.setInteger(0, i + 1);
            sql1.setString(1, m);
            sql1.setString(2, g.getBrojLinije());
            sql1.executeUpdate();

        }
        //    sesija.getTransaction().commit();

        for (int i = 0; i < listaIzabranihVozaca.size(); i++) {
            Integer id = Integer.parseInt(listaIzabranihVozaca.get(i));
            String upit2 = "insert into gvozac values(?,?)";
            SQLQuery sql2 = sesija.createSQLQuery(upit2);
            sql2.setInteger(0, id);
            sql2.setString(1, g.getBrojLinije());
            sql2.executeUpdate();

        }

        sesija.getTransaction().commit();

        medjustanice = "";
        listaIzabranihVozaca = new ArrayList<>();
        g = new Glinija();
        sesija.close();
        messagedg = "Uspesno dodata gradska linija!";
        return null;
    }

    public String registracija() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "SELECT * FROM korisnik where flagReg=1";
        SQLQuery sql = sesija.createSQLQuery(upit);
        reglista = new ArrayList<>();
        List<Object[]> rs = sql.list();
        for (int i = 0; i < rs.size(); i++) {
            Object[] tmp = rs.get(i);
            Korisnik k = new Korisnik();
            k.setIme(tmp[0].toString());
            k.setPrezime(tmp[1].toString());
            k.setUsername(tmp[2].toString());
            k.setPassword(tmp[3].toString());
            k.setAdresa(tmp[4].toString());
            k.setDatumRodjenja((Date) tmp[5]);
            k.setTelefon(tmp[6].toString());
            k.setZanimanje(tmp[7].toString());
            reglista.add(k);

        }
        sesija.close();

        return "adminreg";
    }

    public String odobrireg(Korisnik i) {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "update korisnik set flagReg=0 where username=?";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, i.getUsername());
        sql.executeUpdate();
        sesija.getTransaction().commit();
        reglista.remove(i);
        messagereg = "Uspesno odobrena registracija za korisnika " + i.getUsername() + " !";
        sesija.close();
        return null;
    }

    public String odbijreg(Korisnik i) {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "delete from korisnik where username=?";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, i.getUsername());
        sql.executeUpdate();
        sesija.getTransaction().commit();
        reglista.remove(i);
        messagereg = "Uspesno odbijena registracija za korisnika " + i.getUsername() + " !";
        sesija.close();
        return null;
    }

    public String rezervacija() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "SELECT * FROM rezervacija where zahtev=1";
        SQLQuery sql = sesija.createSQLQuery(upit);
        rlista = new ArrayList<>();
        List<Object[]> rs = sql.list();
        for (int i = 0; i < rs.size(); i++) {
            Object[] tmp = rs.get(i);
            Rezervacija r = new Rezervacija();
            r.getId().setBrojLinije((Integer) tmp[0]);
            r.getId().setUname(tmp[1].toString());
            r.getId().setDatum((Date) tmp[2]);
            r.setBroj((Integer) tmp[3]);
            rlista.add(r);
        }
        sesija.close();
        return "adminrezervacije";
    }

    public String odobrirez(Rezervacija i) {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "SELECT v.broj, v.brojLinije FROM rezervacija r, vecrezkarte v where r.brojLinije=v.brojLinije and r.datum=v.datum and r.brojLinije=? and r.datum=?";

        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setInteger(0, i.getId().getBrojLinije());
        sql.setDate(1, i.getId().getDatum());
        List<Object[]> rs = sql.list();
        if (!rs.isEmpty()) {
            Object[] tmp = rs.get(0);
            Integer brojrez = (Integer) tmp[0];
            String upit1 = "SELECT a.kapacitet, a.marka FROM vecrezkarte v, mautobus m, autobus a where v.brojLinije=? and v.datum=? and v.brojLinije=m.brojLinije and a.id=m.idB and m.datum=v.datum and v.broj + 1 <= a.kapacitet";
            SQLQuery sql1 = sesija.createSQLQuery(upit1);
            sql1.setInteger(0, i.getId().getBrojLinije());
            sql1.setDate(1, i.getId().getDatum());
            List<Object[]> rs1 = sql1.list();
            if (rs1.isEmpty()) {
                messagerez = "Nije moguce odobriti rezervaciju jer nema dovoljno mesta!";
                String upit2 = "DELETE FROM rezervacija WHERE brojLinije =? and uname =? and datum= ?";
                SQLQuery sql2 = sesija.createSQLQuery(upit2);
                sql2.setInteger(0, i.getId().getBrojLinije());
                sql2.setString(1, i.getId().getUname());
                sql2.setDate(2, i.getId().getDatum());
                sql2.executeUpdate();

                String poruka = "Vasa rezervacija za datum " + i.getId().getDatum() + " na liniji " + i.getId().getBrojLinije() + " nije moguca zbog nedostatka mesta u busu!";
                String upit3 = "insert into poruka(uname,sadrzaj) values (?,?)";
                SQLQuery sql3 = sesija.createSQLQuery(upit3);
                sql3.setString(0, i.getId().getUname());
                sql3.setString(1, poruka);
                sql3.executeUpdate();
                rlista.remove(i);
                //obavesti korisnika i obrisi iz tabele rez
            } else {
                messagerez = "Uspesno ste odobrili rezervaciju!";
                String upit2 = "update rezervacija set zahtev=0 where brojLinije=? and uname=? and datum=?";
                SQLQuery sql2 = sesija.createSQLQuery(upit2);
                sql2.setInteger(0, i.getId().getBrojLinije());
                sql2.setString(1, i.getId().getUname());
                sql2.setDate(2, i.getId().getDatum());
                sql2.executeUpdate();

                String poruka = "Vasa rezervacija za datum " + i.getId().getDatum() + " na liniji " + i.getId().getBrojLinije() + " je odobrena!";
                String upit3 = "insert into poruka(uname,sadrzaj) values (?,?)";
                SQLQuery sql3 = sesija.createSQLQuery(upit3);
                sql3.setString(0, i.getId().getUname());
                sql3.setString(1, poruka);
                sql3.executeUpdate();

                String upit4 = "update vecrezkarte set broj=? where brojLinije=? and datum=?";
                SQLQuery sql4 = sesija.createSQLQuery(upit4);
                sql4.setInteger(0, brojrez + 1);
                sql4.setInteger(1, i.getId().getBrojLinije());
                sql4.setDate(2, i.getId().getDatum());
                sql4.executeUpdate();
                rlista.remove(i);
                //obaesti korisnika i obrisi zahtev i uvecaj broj za 1
            }
        } else {
            String upit1 = "insert into vecrezkarte values (?,?,?)";
            SQLQuery sql1 = sesija.createSQLQuery(upit1);
            sql1.setInteger(0, i.getId().getBrojLinije());
            sql1.setDate(1, i.getId().getDatum());
            sql1.setInteger(2, 1);
            sql1.executeUpdate();

            String poruka = "Vasa rezervacija za datum " + i.getId().getDatum() + " na liniji " + i.getId().getBrojLinije() + " je odobrena!";
            String upit3 = "insert into poruka(uname,sadrzaj) values (?,?)";
            SQLQuery sql3 = sesija.createSQLQuery(upit3);
            sql3.setString(0, i.getId().getUname());
            sql3.setString(1, poruka);
            sql3.executeUpdate();

            messagerez = "Uspesno ste odobrili rezervaciju!";
            String upit2 = "update rezervacija set zahtev=0 where brojLinije=? and uname=? and datum=?";
            SQLQuery sql2 = sesija.createSQLQuery(upit2);
            sql2.setInteger(0, i.getId().getBrojLinije());
            sql2.setString(1, i.getId().getUname());
            sql2.setDate(2, i.getId().getDatum());
            sql2.executeUpdate();
            rlista.remove(i);
            //ubaci broj 1 i obaesti korisnik i obrisi zaht
        }
        sesija.getTransaction().commit();
        sesija.close();
        return null;
    }

    public String odbijrez(Rezervacija i) {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        messagerez = "Uspesno odbijena rezervacija!";
        String upit2 = "DELETE FROM rezervacija WHERE brojLinije =? and uname =? and datum= ?";
        SQLQuery sql2 = sesija.createSQLQuery(upit2);
        sql2.setInteger(0, i.getId().getBrojLinije());
        sql2.setString(1, i.getId().getUname());
        sql2.setDate(2, i.getId().getDatum());
        sql2.executeUpdate();

        String poruka = "Vasa rezervacija za datum " + i.getId().getDatum() + " na liniji " + i.getId().getBrojLinije() + " je odbijena!";
        String upit3 = "insert into poruka(uname,sadrzaj) values (?,?)";
        SQLQuery sql3 = sesija.createSQLQuery(upit3);
        sql3.setString(0, i.getId().getUname());
        sql3.setString(1, poruka);
        sql3.executeUpdate();
        rlista.remove(i);
        sesija.getTransaction().commit();
        sesija.close();
        return null;
    }

    public String kartice() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "select * from kartica where zahtev=1";
        SQLQuery sql = sesija.createSQLQuery(upit);
        klista = new ArrayList<>();
        List<Object[]> rs = sql.list();
        for (int i = 0; i < rs.size(); i++) {
            Object[] tmp = rs.get(i);
            Kartica k = new Kartica();
            k.setVrsta(tmp[0].toString());
            k.setUname(tmp[2].toString());
            klista.add(k);

        }
        sesija.close();
        return "adminkartice";
    }

    public String odobrik(Kartica i) {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "update kartica set zahtev=0 where uname=?";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, i.getUname());
        sql.executeUpdate();
        messagek = "Uspesno ste odobrili zahtev za karticu za korisnika " + i.getUname() + " !";
        String poruka = "Vas zahtev za karticu je odobren!";
        String upit1 = "insert into poruka(uname,sadrzaj) values (?,?)";
        SQLQuery sql1 = sesija.createSQLQuery(upit1);
        sql1.setString(0, i.getUname());
        sql1.setString(1, poruka);
        sql1.executeUpdate();
        klista.remove(i);
        sesija.getTransaction().commit();
        sesija.close();
        return null;
    }

    public String odbijk(Kartica i) {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "delete from kartica where uname=?";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, i.getUname());
        sql.executeUpdate();
        messagek = "Uspesno ste odbili zahtev za karticu za korisnika " + i.getUname() + " !";
        String poruka = "Vas zahtev za karticu je odbijen!";
        String upit1 = "insert into poruka(uname,sadrzaj) values (?,?)";
        SQLQuery sql1 = sesija.createSQLQuery(upit1);
        sql1.setString(0, i.getUname());
        sql1.setString(1, poruka);
        sql1.executeUpdate();
        klista.remove(i);
        sesija.getTransaction().commit();
        sesija.close();
        return null;
    }

    public String medjugradske() {

        return "adminmgizaberi";
    }

    public String dodajMGL1() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "SELECT * FROM prevoznik";
        SQLQuery sql = sesija.createSQLQuery(upit);

        plista = new ArrayList<>();
        List<Object[]> rs = sql.list();
        for (int i = 0; i < rs.size(); i++) {
            Object[] tmp = rs.get(i);
            Prevoznik p = new Prevoznik();
            p.setIdPrevoznika((Integer) tmp[0]);

            p.setNaziv(tmp[2].toString());
            p.setAdresa(tmp[3].toString());
            p.setTelefon(tmp[4].toString());
            plista.add(p);

        }
        sesija.close();
        return "adminmedjugradske";
    }

    public void dalje() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();

        if (indeks == 0) {

            String upit1 = "select * from mlinija where brojLinije=?";
            SQLQuery sql1 = sesija.createSQLQuery(upit1);
            sql1.setInteger(0, nova.getBrojLinije());
            List<Object[]> rs1 = sql1.list();

            if (rs1.size() > 0) {
                mgmessage = "Broj linije vec postoji";
                indeks = 0;
                return;
            }

            indeks++;
            return;
        } else {
            if (indeks == 2) {
                if (nova.getDatum() == null) {
                    indeks = 5;
                    return;
                } else {
                    String upit = "SELECT * FROM `autobus` WHERE id not in (select idB from mautobus where datum = ?)";
                    SQLQuery sql = sesija.createSQLQuery(upit);
                    sql.setDate(0, nova.getDatum());
                    alista = new ArrayList<>();
                    List<Object[]> rs = sql.list();
                    for (int i = 0; i < rs.size(); i++) {
                        Object[] tmp = rs.get(i);
                        Autobus a = new Autobus();
                        a.setId((Integer) tmp[0]);
                        a.setModel(tmp[1].toString());
                        a.setMarka(tmp[2].toString());
                        a.setKapacitet((Integer) tmp[3]);
                        alista.add(a);
                    }
                    //////////////////////////////////////
                     upit = "SELECT * from vozac where id not in (select idVozaca from mvozac where datum = ?)";
                     sql = sesija.createSQLQuery(upit);
                    sql.setDate(0, nova.getDatum());
                    listavoz = new ArrayList<>();
                    rs = sql.list();
                    for (int i = 0; i < rs.size(); i++) {
                        Object[] tmp = rs.get(i);
                        Vozac vv = new Vozac();
                        vv.setId((Integer) tmp[0]);
                        vv.setIme(tmp[1].toString());
                        vv.setPrezime(tmp[2].toString());
                        vv.setDatumRodjenja((Date) tmp[3]);
                        vv.setGodinaPocetka((Integer) tmp[4]);
                        
                        listavoz.add(vv);
                    }
                    
                    indeks++;
                    return;
                }
            } else {
                indeks++;
                return;

            }
        }

       

    }

    public String dodajmliniju() {
        indeks = 0;
        
        if (nova.getDatum() == null) {
            dodajMGBezDatuma();
            return null;
        }
        if (flagDodajDodaj) {
            dopuniPodatkeML();
            return null;
        }
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "insert into mlinija values (?,?,?,?,?,?)";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, nova.getPocetnoOdrediste());
        sql.setString(1, nova.getKrajnjeOdrediste());
        sql.setInteger(2, nova.getBrojLinije());
        String tmpx=nova.getVremena().split("-")[0];
        String sati = tmpx.substring(0, 2);
        String minuti = tmpx.substring(3, 5);
        String sekunde = tmpx.substring(6);
        Time vremePolaska = new Time(Integer.parseInt(sati), Integer.parseInt(minuti), Integer.parseInt(sekunde));
        sql.setTime(3, vremePolaska);
        sql.setDate(4, nova.getDatum());
        sql.setInteger(5, nova.getIdPrevoznika());

        sql.executeUpdate();

        String upit1 = "insert into mvozac values (?,?,?)";
        SQLQuery sql1 = sesija.createSQLQuery(upit1);
        sql1.setInteger(0, nova.getIdVozaca());
        sql1.setInteger(1, nova.getBrojLinije());
        sql1.setDate(2, nova.getDatum());
        sql1.executeUpdate();

        String upit2 = "insert into mautobus values (?,?,?)";
        SQLQuery sql2 = sesija.createSQLQuery(upit2);
        sql2.setInteger(0, nova.getIdBusa());
        sql2.setInteger(1, nova.getBrojLinije());
        sql2.setDate(2, nova.getDatum());
        sql2.executeUpdate();

        String[] stajalista = nova.getMedjustanice().split("-");
        String[] vremena = nova.getVremena().split("-");
        String[] koordinate1 = nova.getK1().split("-");
        String[] koordinate2 = nova.getK2().split("-");

        for (int i = 0; i < stajalista.length; i++) {
            if (vremena[i] != null) {
                //uneto vreme
                sati = vremena[i].substring(0, 2);
                minuti = vremena[i].substring(3, 5);
                sekunde = vremena[i].substring(6);
                vremePolaska = new Time(Integer.parseInt(sati), Integer.parseInt(minuti), Integer.parseInt(sekunde));
                double k1=Double.parseDouble(koordinate1[i]);
                double k2=Double.parseDouble(koordinate2[i]);
                upit2 = "insert into stajaliste values (?,?,?,?,?,?)";
                sql2 = sesija.createSQLQuery(upit2);
                sql2.setDouble(0, k1);
                sql2.setDouble(1, k2);
                sql2.setInteger(2, i + 1);
                sql2.setString(3, stajalista[i]);
                sql2.setTime(4, vremePolaska);
                sql2.setInteger(5, nova.getBrojLinije());
            } else {
                upit2 = "insert into stajaliste values (0,0,?,?,NULL,?)";
                sql2 = sesija.createSQLQuery(upit2);
                sql2.setInteger(0, i + 1);
                sql2.setString(1, stajalista[i]);
                sql2.setInteger(2, nova.getBrojLinije());
            }

            sql2.executeUpdate();

        }

        sesija.getTransaction().commit();
        sesija.close();
        mgmessage = "Uspesno dodata medjugradska linija!";

        return null;
    }

    public void upload1(FileUploadEvent event) {
        uploadedFile = event.getFile();
    }

    public void dodajprevoznika() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        if (uploadedFile != null) {
            byte[] contents = uploadedFile.getContents();
            String nastavak;
            String path;
            // String nastavak;
            if (uploadedFile.getContentType().contains("png")) {
                nastavak = ".png";

            } else {
                if (uploadedFile.getContentType().contains("jpeg") || uploadedFile.getContentType().contains("jpg")) {
                    nastavak = ".jpg";
                } else {
                    nastavak = ".gif";
                }
            }
            path = "C:\\Users\\User\\Documents\\NetBeansProjects\\Ticalo\\web\\slike\\";

            path += prev.getNaziv() + nastavak;
            if ((path.isEmpty() == false) && (path.equals("") == false)) {
                File file = new File(path);
                try {
                    file.createNewFile();

                    FileOutputStream out = new FileOutputStream(file);
                    if (out != null && contents != null) {
                        out.write(contents);

                        prev.setLogo(prev.getNaziv() + nastavak);

                    }

                } catch (FileNotFoundException ex) {
                    Logger.getLogger(ControlerAdmin.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(ControlerAdmin.class.getName()).log(Level.SEVERE, null, ex);
                }
                path = "";
            }
            path = "";
        }
        String upit;
        SQLQuery sql;
        if (uploadedFile != null) {
            upit = "insert into prevoznik(logo,naziv,adresa,telefon) values (?,?,?,?)";
            sql = sesija.createSQLQuery(upit);
            sql.setString(0, prev.getLogo());
            sql.setString(1, prev.getNaziv());
            sql.setString(2, prev.getAdresa());
            sql.setString(3, prev.getTelefon());
            sql.executeUpdate();
        } else {
            upit = "insert into prevoznik(naziv,adresa,telefon) values (?,?,?)";
            sql = sesija.createSQLQuery(upit);
            sql.setString(0, prev.getNaziv());
            sql.setString(1, prev.getAdresa());
            sql.setString(2, prev.getTelefon());
            sql.executeUpdate();

        }

        sesija.getTransaction().commit();
        prev = new Prevoznik();
        upit = "SELECT * FROM prevoznik";
        sql = sesija.createSQLQuery(upit);

        plista = new ArrayList<>();
        List<Object[]> rs = sql.list();
        for (int i = 0; i < rs.size(); i++) {
            Object[] tmp = rs.get(i);
            Prevoznik p = new Prevoznik();
            p.setIdPrevoznika((Integer) tmp[0]);
            if (tmp[1] != null) {
                p.setLogo(tmp[1].toString());
            }

            p.setNaziv(tmp[2].toString());
            p.setAdresa(tmp[3].toString());
            p.setTelefon(tmp[4].toString());
            plista.add(p);

        }

        sesija.close();
        prevmessage = "Uspesno ste dodali prevoznika!";

    }

    public String adminprevoznik() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        prev = new Prevoznik();
        String upit = "SELECT * FROM prevoznik";
        SQLQuery sql = sesija.createSQLQuery(upit);

        plista = new ArrayList<>();
        List<Object[]> rs = sql.list();
        for (int i = 0; i < rs.size(); i++) {
            Object[] tmp = rs.get(i);
            Prevoznik p = new Prevoznik();
            p.setIdPrevoznika((Integer) tmp[0]);
            if (tmp[1] != null) {
                p.setLogo(tmp[1].toString());
            }

            p.setNaziv(tmp[2].toString());
            p.setAdresa(tmp[3].toString());
            p.setTelefon(tmp[4].toString());
            plista.add(p);

        }
        return "adminprevoznik";
    }

    public String dodajv() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "insert into vozac(ime,prezime,datumRodjenja,godinaPocetka) values (?,?,?,?)";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, vozac.getIme());
        sql.setString(1, vozac.getPrezime());
        sql.setDate(2, vozac.getDatumRodjenja());
        sql.setInteger(3, vozac.getGodinaPocetka());
        sql.executeUpdate();
        sesija.getTransaction().commit();
        vozac = new Vozac();
        sesija.close();
        messagevoz = "Uspesno dodat vozac!";
        return null;
    }

    public String dodajbus() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "insert into autobus(model,marka,kapacitet) values (?,?,?)";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, bus.getModel());
        sql.setString(1, bus.getMarka());
        sql.setInteger(2, bus.getKapacitet());
        sql.executeUpdate();
        sesija.getTransaction().commit();

        bus = new Autobus();
        sesija.beginTransaction();
        upit = "SELECT max(id), marka from autobus";
        sql = sesija.createSQLQuery(upit);
        List<Object[]> rs = sql.list();
        Object[] tmp = rs.get(0);
        id = (Integer) tmp[0];

        if (fajllist.size() > 0) {
            for (int i = 0; i < fajllist.size(); i++) {
                try {
                    byte[] contents = uploadedFile.getContents();
                    String nastavak;
                    String path;
                    // String nastavak;
                    if (uploadedFile.getContentType().contains("png")) {
                        nastavak = ".png";

                    } else {
                        if (uploadedFile.getContentType().contains("jpeg") || uploadedFile.getContentType().contains("jpg")) {
                            nastavak = ".jpg";
                        } else {
                            nastavak = ".gif";
                        }
                    }
                    String naziv = +id + "" + i + "" + nastavak;
                    path = "C:\\Users\\User\\Documents\\NetBeansProjects\\Ticalo\\web\\slike\\" + naziv;

                    s = new Slika();
                    s.getId().setIdBusa(id);
                    s.setSlika(naziv);
                    s.getId().setRedniBroj(i + 1);
                    String upit1 = "insert into slika values (?,?,?)";
                    SQLQuery sql1 = sesija.createSQLQuery(upit1);
                    sql1.setInteger(0, s.getId().getRedniBroj());
                    sql1.setString(1, s.getSlika());
                    sql1.setInteger(2, s.getId().getIdBusa());
                    sql1.executeUpdate();

                    File file = new File(path);

                    file.createNewFile();

                    FileOutputStream out = new FileOutputStream(file);
                    out.write(contents);
                } catch (IOException ex) {
                    Logger.getLogger(ControlerAdmin.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        }
        sesija.getTransaction().commit();
        sesija.close();
        messagebus = "Uspesno dodat autobus!";
        return null;
    }

    public void upload2(FileUploadEvent event) {

        uploadedFile = event.getFile();
        fajllist.add(uploadedFile);

        if (fajllist.size() > 5) {
            messagebus = "Ne smete dodati vise od 5 slika!";
        }
    }

    private void dodajMGBezDatuma() {
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "insert into mlinija (pocetnoOdrediste,krajnjeOdrediste,brojLinije,idPrevoznika) values (?,?,?,?)";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, nova.getPocetnoOdrediste());
        sql.setString(1, nova.getKrajnjeOdrediste());
        sql.setInteger(2, nova.getBrojLinije());
        sql.setInteger(3, nova.getIdPrevoznika());

        sql.executeUpdate();
        
        
        String[] stajalista = nova.getMedjustanice().split("-");
        

        for (int i = 0; i < stajalista.length; i++) {
           
               
                String upit1 = "insert into stajaliste (k1,k2,redniBroj,mesto,brojLinije) values (0,0,?,?,?)";
                SQLQuery sql1 = sesija.createSQLQuery(upit1);
                sql1.setInteger(0, i + 1);
                sql1.setString(1, stajalista[i]);
                sql1.setInteger(2, nova.getBrojLinije());
           

            sql1.executeUpdate();

        }

        sesija.getTransaction().commit();
        sesija.close();
        mgmessage = "Uspesno dodata medjugradska linija!";

       
    }
    
    public String dodajnaknadno(){
         Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit = "select * from mlinija where datum is null";
        SQLQuery sql = sesija.createSQLQuery(upit);
        listam = new ArrayList<>();
        List<Object[]> rs = sql.list();
        for (int i = 0; i < rs.size(); i++) {
            Object[] tmp = rs.get(i);
            Mlinija m=new Mlinija();
            m.setPocetnoOdrediste(tmp[0].toString());
            m.setKrajnjeOdrediste(tmp[1].toString());
            m.setBrojLinije((Integer)tmp[2]);
            m.setIdBusa((Integer)tmp[5]);
            
            
            
            String upit1="select s.mesto, s.brojLinije from stajaliste s, mlinija m where m.brojLinije = s.brojLinije and m.brojLinije = ?";
                      SQLQuery sql1 = sesija.createSQLQuery(upit1);
                      sql1.setInteger(0, (Integer)tmp[2]);
                       List<Object[]> rs1 = sql1.list();
                StringBuilder sb = new StringBuilder();
                for (int ii = 0; ii < rs1.size(); ii++) {
                    Object[] tmp1 = rs1.get(ii);
                    sb.append(tmp1[0].toString());
                    sb.append("-");

                }
                  m.setMedjustanice(sb.toString());
         listam.add(m);
        }
        sesija.close();
        
        return "adminlistanaknadno";
    }
    private boolean flagDodajDodaj=false;
    
    public String dodajvid(Mlinija i){
        
        nova.setBrojLinije(i.getBrojLinije());
        nova.setPocetnoOdrediste(i.getPocetnoOdrediste());
        nova.setKrajnjeOdrediste(i.getKrajnjeOdrediste());
        nova.setIdPrevoznika(i.getIdPrevoznika());
        nova.setMedjustanice(i.getMedjustanice());
        indeks=2;
        flagDodajDodaj=true;
        mgmessage="";
        return "adminmedjugradske";
    }

    private void dopuniPodatkeML() {
        
        flagDodajDodaj=false;
        Session sesija = HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
     
       
        String upit = "update mlinija set vremePolaska = ?, datum =? where brojLinije = ?";
        SQLQuery sql = sesija.createSQLQuery(upit);
      
        String tmpx=nova.getVremena().split("-")[0];
        String sati = tmpx.substring(0, 2);
        String minuti = tmpx.substring(3, 5);
        String sekunde = tmpx.substring(6);
        Time vremePolaska = new Time(Integer.parseInt(sati), Integer.parseInt(minuti), Integer.parseInt(sekunde));
        sql.setTime(0, vremePolaska);
        sql.setDate(1, nova.getDatum());
        sql.setInteger(2, nova.getBrojLinije());

        sql.executeUpdate();

        String upit1 = "insert into mvozac values (?,?,?)";
        SQLQuery sql1 = sesija.createSQLQuery(upit1);
        sql1.setInteger(0, nova.getIdVozaca());
        sql1.setInteger(1, nova.getBrojLinije());
        sql1.setDate(2, nova.getDatum());
        sql1.executeUpdate();

        String upit2 = "insert into mautobus values (?,?,?)";
        SQLQuery sql2 = sesija.createSQLQuery(upit2);
        sql2.setInteger(0, nova.getIdBusa());
        sql2.setInteger(1, nova.getBrojLinije());
        sql2.setDate(2, nova.getDatum());
        sql2.executeUpdate();
        
        String[] stajalista = nova.getMedjustanice().split("-");
        String[] vremena = nova.getVremena().split("-");
        String[] koordinate1 = nova.getK1().split("-");
        String[] koordinate2 = nova.getK2().split("-");
 
        for (int i = 0; i < stajalista.length; i++) {
            if (vremena[i] != null) {
                //uneto vreme
                sati = vremena[i].substring(0, 2);
                minuti = vremena[i].substring(3, 5);
                sekunde = vremena[i].substring(6);
                vremePolaska = new Time(Integer.parseInt(sati), Integer.parseInt(minuti), Integer.parseInt(sekunde));
                double k1=Double.parseDouble(koordinate1[i]);
                double k2=Double.parseDouble(koordinate2[i]);
                upit2 = "update stajaliste set k1 = ?, k2 = ?, vremePolaska = ? where brojLinije = ? and redniBroj = ?";
                sql2 = sesija.createSQLQuery(upit2);
                sql2.setDouble(0, k1);
                sql2.setDouble(1, k2);
                sql2.setTime(2, vremePolaska);
                sql2.setInteger(3, nova.getBrojLinije());
                sql2.setInteger(4, i+1);
            } else {
                upit2 = "insert into stajaliste values (0,0,?,?,NULL,?)";
                sql2 = sesija.createSQLQuery(upit2);
                sql2.setInteger(0, i + 1);
                sql2.setString(1, stajalista[i]);
                sql2.setInteger(2, nova.getBrojLinije());
            }

            sql2.executeUpdate();

        }

        sesija.getTransaction().commit();
        sesija.close();
        mgmessage = "Uspesno dopunjena medjugradska linija!";
        
    }
    //  String upit2 = "update stajalista set vremePolaska = ?, kord1 = ?, kord2 = ? where brojLinije = ? and redniBroj = ? ";
}
