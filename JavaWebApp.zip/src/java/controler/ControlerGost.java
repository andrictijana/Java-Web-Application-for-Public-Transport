/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import config.HibernateUtil;
import java.io.Serializable;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import util.Gost;
import util.Stajalista;

/**
 *
 * @author Tijana
 */
@Named(value = "con1")
@SessionScoped
public class ControlerGost implements Serializable {

    private Gost gost = new Gost();
    private String message;
    private ArrayList<Stajalista> listas = new ArrayList<>();
    private ArrayList<Stajalista> listanaj = new ArrayList<>();

    public ArrayList<Stajalista> getListanaj() {
        return listanaj;
    }

    public void setListanaj(ArrayList<Stajalista> listanaj) {
        this.listanaj = listanaj;
    }
    

    public ArrayList<Stajalista> getListas() {
        return listas;
    }

    public void setListas(ArrayList<Stajalista> listas) {
        this.listas = listas;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Gost getGost() {
        return gost;
    }

    public void setGost(Gost gost) {
        this.gost = gost;
    }
    
    //////////////
     public String najskoriji(){
        
            Session sesija = HibernateUtil.getSessionFactory().openSession();
            sesija.beginTransaction();
            
            String upit="SELECT s.mesto, s.vremePolaska, s.redniBroj, m.brojLinije, m.datum, p.naziv FROM stajaliste s , mlinija m, prevoznik p WHERE s.brojLinije=m.brojLinije and m.idPrevoznika=p.idPrevoznika and (( s.vremePolaska >= CURRENT_TIME and m.datum = CURRENT_DATE) or ( m.datum > CURRENT_DATE)) and s.mesto != m.krajnjeOdrediste order by m.datum asc, s.vremePolaska asc;";

            SQLQuery sgl = sesija.createSQLQuery(upit);
           

            listanaj = new ArrayList<>();
            List<Object[]> rs = sgl.list();
            for (int i = 0; i < 10; i++) {
                Object[] tmp = rs.get(i);
                Stajalista s = new Stajalista();
                s.setIme(tmp[0].toString());
                s.setBrojlinije(Integer.parseInt(tmp[3].toString()));
                s.setVremepolaska(tmp[1].toString());
                s.setPrevoznik(tmp[5].toString());
                s.setDatum((Date)tmp[4]); 

                int rednibr = Integer.parseInt(tmp[2].toString());
                String upit1 = "SELECT s.mesto, s.redniBroj FROM stajaliste s , mlinija m WHERE s.brojLinije=m.brojLinije and s.redniBroj >= ? and m.brojLinije=?";

                SQLQuery sql1 = sesija.createSQLQuery(upit1);
                sql1.setInteger(0, rednibr);
                sql1.setInteger(1, s.getBrojlinije());

                List<Object[]> rs1 = sql1.list();
              
                StringBuilder sb = new StringBuilder();
                for (int ii = 0; ii < rs1.size(); ii++) {
                    Object[] tmp1 = rs1.get(ii);
                    sb.append(tmp1[0].toString());
                    sb.append("\t");

                }
                s.setMedjustanice(sb.toString());

                listanaj.add(s);

            }
           
        
        return "gostnajskoriji";
    }
///////////////////////////////////
    public String pretraga() {
        String polaziste = gost.getMestoPolazista();
        String odrediste = gost.getMestoOdredista();
        if (polaziste.equals("") || polaziste == null) {
            if (odrediste.equals("") || odrediste == null) {
                message = "Morate uneti mesto polaska ili mesto dolaska!";
                return null;
            }

        }
        String od = gost.getOd();
        String doo = gost.getDoo();
        if (((od == null) || (od.equals(""))) && !( (doo == null) || (doo.equals("") ) ) ) {
            message = "Morate uneti ceo vremenski opseg!";
            return null;
        }
        if (((od != null) && !(od.equals(""))) && ((doo == null) || (doo.equals("")))) {
            message = "Morate uneti ceo vremenski opseg!";
            return null;
        }
        if ((gost.getNazivPrevoznika() == null || gost.getNazivPrevoznika().equals("")) && (gost.getOd() == null || gost.getOd().equals("")) && (gost.getDoo() == null || gost.getDoo().equals("")) && (gost.getMestoPolazista() != null || gost.getMestoPolazista().equals("")) && (gost.getMestoOdredista() == null || gost.getMestoOdredista().equals(""))) {
            Session sesija = HibernateUtil.getSessionFactory().openSession();
            sesija.beginTransaction();
            String upit = "SELECT s.mesto, s.brojLinije, s.vremePolaska, p.naziv, s.redniBroj FROM `stajaliste` s, mlinija m, prevoznik p WHERE s.mesto = ? and s.brojLinije = m.brojLinije and m.idPrevoznika=p.idPrevoznika and m.datum = ?";

            SQLQuery sgl = sesija.createSQLQuery(upit);
            sgl.setString(0, gost.getMestoPolazista());
            sgl.setDate(1, gost.getDatum());

            listas = new ArrayList<>();
            List<Object[]> rs = sgl.list();
            for (int i = 0; i < rs.size(); i++) {
                Object[] tmp = rs.get(i);
                Stajalista s = new Stajalista();
                s.setIme(tmp[0].toString());
                s.setBrojlinije(Integer.parseInt(tmp[1].toString()));
                s.setVremepolaska(tmp[2].toString());
                s.setPrevoznik(tmp[3].toString());
                s.setDatum(gost.getDatum());

                int rednibr = Integer.parseInt(tmp[4].toString());
                String upit1 = "SELECT s.mesto, s.redniBroj FROM stajaliste s , mlinija m WHERE s.brojLinije=m.brojLinije and s.redniBroj >= ? and m.brojLinije=?";

                SQLQuery sql1 = sesija.createSQLQuery(upit1);
                sql1.setInteger(0, rednibr);
                sql1.setInteger(1, s.getBrojlinije());
int cnt=0;
                List<Object[]> rs1 = sql1.list();
                StringBuilder sb = new StringBuilder();
                for (int ii = 0; ii < rs1.size(); ii++) {
                    Object[] tmp1 = rs1.get(ii);
                    sb.append(tmp1[0].toString());
                    sb.append("\t");
                    cnt++;

                }
                s.setMedjustanice(sb.toString());
if (cnt >= 2) 
                listas.add(s);

            }
            return "pretraga";
        } else {
            if ((gost.getNazivPrevoznika() == null || gost.getNazivPrevoznika().equals("")) && (gost.getOd() == null || gost.getOd().equals("")) && (gost.getDoo() == null || gost.getDoo().equals("")) && (gost.getMestoPolazista() == null || gost.getMestoPolazista().equals("")) && (gost.getMestoOdredista() != null || !gost.getMestoOdredista().equals(""))) {
                Session sesija = HibernateUtil.getSessionFactory().openSession();
                sesija.beginTransaction();
                String upit = "SELECT s.mesto, s.brojLinije, s.vremePolaska, p.naziv, s.redniBroj FROM `stajaliste` s, mlinija m, prevoznik p WHERE s.mesto = ? and s.brojLinije = m.brojLinije and m.idPrevoznika=p.idPrevoznika and m.datum = ?";

                SQLQuery sgl = sesija.createSQLQuery(upit);
                sgl.setString(0, gost.getMestoOdredista());
                sgl.setDate(1, gost.getDatum());

                listas = new ArrayList<>();
                List<Object[]> rs = sgl.list();
                for (int i = 0; i < rs.size(); i++) {
                    Object[] tmp = rs.get(i);
                    Stajalista s = new Stajalista();
                    s.setIme(tmp[0].toString());
                    s.setBrojlinije(Integer.parseInt(tmp[1].toString()));

                    s.setPrevoznik(tmp[3].toString());
                    s.setDatum(gost.getDatum());

                    int rednibr = Integer.parseInt(tmp[4].toString());
                    String upit1 = "SELECT s.mesto, s.redniBroj, s.vremePolaska FROM stajaliste s , mlinija m WHERE s.brojLinije=m.brojLinije and s.redniBroj <= ? and m.brojLinije=?";

                    SQLQuery sql1 = sesija.createSQLQuery(upit1);
                    sql1.setInteger(0, rednibr);
                    sql1.setInteger(1, s.getBrojlinije());

                    List<Object[]> rs1 = sql1.list();
                    /*
                    Object[] tmp2 = rs1.get(0);
                    String polazak = tmp2[2].toString();
                    s.setVremepolaska(polazak); */
                    
                    String upit2="select * from mlinija where brojLinije= ?";
                   SQLQuery sql2 = sesija.createSQLQuery(upit2);
                    sql2.setInteger(0, s.getBrojlinije());
                    List<Object[]> rs2 = sql2.list();
                   Object[] tmp2=rs2.get(0);
                   String polazak=tmp2[3].toString();
                   s.setVremepolaska(polazak);
int cnt=0;
                    StringBuilder sb = new StringBuilder();
                    for (int ii = 0; ii < rs1.size(); ii++) {
                        Object[] tmp1 = rs1.get(ii);
                        sb.append(tmp1[0].toString());
                        sb.append("\t");
                        cnt++;

                    }
                    s.setMedjustanice(sb.toString());
if (cnt >= 2) 
                    listas.add(s);

                }
                return "pretraga";
            } else {
                if ((gost.getNazivPrevoznika() == null || gost.getNazivPrevoznika().equals("")) && (gost.getOd() == null || gost.getOd().equals("")) && (gost.getDoo() == null || gost.getDoo().equals("")) && (gost.getMestoPolazista() != null || !gost.getMestoPolazista().equals("")) && (gost.getMestoOdredista() != null || !gost.getMestoOdredista().equals(""))) {
                    Session sesija = HibernateUtil.getSessionFactory().openSession();
                    sesija.beginTransaction();
                    String upit1="select s1.redniBroj as br1, s1.vremePolaska, s1.brojLinije, s2.redniBroj as br2 from stajaliste s1, stajaliste s2, mlinija m where s1.brojLinije = m.brojLinije and s1.brojLinije=s2.brojLinije and s1.redniBroj < s2.redniBroj and s1.mesto = ? and s2.mesto = ? and m.datum = ?"  ;
                     SQLQuery sql = sesija.createSQLQuery(upit1);
                sql.setString(0, gost.getMestoPolazista());
                sql.setString(1, gost.getMestoOdredista());
                sql.setDate(2, gost.getDatum());
                
                listas = new ArrayList<>();
                List<Object[]> rs = sql.list();
                for (int i = 0; i < rs.size(); i++) {
                    Object[] tmp = rs.get(i);
                    Stajalista s = new Stajalista();
                   
                    s.setBrojlinije(Integer.parseInt(tmp[2].toString()));
                    s.setVremepolaska(tmp[1].toString());

                    
                    s.setDatum(gost.getDatum());

                    int rednibr1 = Integer.parseInt(tmp[0].toString());
                    int rednibr2= Integer.parseInt(tmp[3].toString());
                    String upit = "SELECT s.mesto, s.redniBroj,p.naziv FROM stajaliste s , mlinija m, prevoznik p WHERE m.idPrevoznika = p.idPrevoznika and s.brojLinije=m.brojLinije and s.redniBroj <= ? and s.redniBroj >= ? and m.brojLinije=?";

                    SQLQuery sql1 = sesija.createSQLQuery(upit);
                    sql1.setInteger(0, rednibr2);
                    sql1.setInteger(1, rednibr1);
                    sql1.setInteger(2, s.getBrojlinije());

                    List<Object[]> rs1 = sql1.list();
                    
                    Object[] tmp2 = rs1.get(0);
                    String prevoznik = tmp2[2].toString();
                    s.setPrevoznik(prevoznik); 
                    int cnt=0;
                   

                    StringBuilder sb = new StringBuilder();
                    for (int ii = 0; ii < rs1.size(); ii++) {
                        Object[] tmp1 = rs1.get(ii);
                        sb.append(tmp1[0].toString());
                        sb.append("\t");
                        cnt++;

                    }
                    s.setMedjustanice(sb.toString());
if (cnt >= 2)
                    listas.add(s);

                }
                return "pretraga";
                
                
            } else {
                    
                    if ((gost.getNazivPrevoznika() == null || gost.getNazivPrevoznika().equals("")) && (gost.getOd() == null || gost.getOd().equals("")) && (gost.getDoo() == null || gost.getDoo().equals("")) && (gost.getMestoPolazista() != null || gost.getMestoPolazista().equals("")) && (gost.getMestoOdredista() == null || gost.getMestoOdredista().equals(""))) {
            Session sesija = HibernateUtil.getSessionFactory().openSession();
            sesija.beginTransaction();
            String upit = "SELECT s.mesto, s.brojLinije, s.vremePolaska, p.naziv, s.redniBroj FROM `stajaliste` s, mlinija m, prevoznik p WHERE s.mesto = ? and s.brojLinije = m.brojLinije and m.idPrevoznika=p.idPrevoznika and m.datum = ?";

            SQLQuery sgl = sesija.createSQLQuery(upit);
            sgl.setString(0, gost.getMestoPolazista());
            sgl.setDate(1, gost.getDatum());

            listas = new ArrayList<>();
            List<Object[]> rs = sgl.list();
            for (int i = 0; i < rs.size(); i++) {
                Object[] tmp = rs.get(i);
                Stajalista s = new Stajalista();
                s.setIme(tmp[0].toString());
                s.setBrojlinije(Integer.parseInt(tmp[1].toString()));
                s.setVremepolaska(tmp[2].toString());
                s.setPrevoznik(tmp[3].toString());
                s.setDatum(gost.getDatum());

                int rednibr = Integer.parseInt(tmp[4].toString());
                String upit1 = "SELECT s.mesto, s.redniBroj FROM stajaliste s , mlinija m WHERE s.brojLinije=m.brojLinije and s.redniBroj >= ? and m.brojLinije=?";

                SQLQuery sql1 = sesija.createSQLQuery(upit1);
                sql1.setInteger(0, rednibr);
                sql1.setInteger(1, s.getBrojlinije());
int cnt=0;
                List<Object[]> rs1 = sql1.list();
                StringBuilder sb = new StringBuilder();
                for (int ii = 0; ii < rs1.size(); ii++) {
                    Object[] tmp1 = rs1.get(ii);
                    sb.append(tmp1[0].toString());
                    sb.append("\t");
                    cnt++;

                }
                s.setMedjustanice(sb.toString());
if (cnt >= 2) {
                listas.add(s);
}

            }
            return "pretraga";
        } else {
            if ((gost.getNazivPrevoznika() != null || !gost.getNazivPrevoznika().equals("")) && (gost.getOd() == null || gost.getOd().equals("")) && (gost.getDoo() == null || gost.getDoo().equals("")) && (gost.getMestoPolazista() != null || !gost.getMestoPolazista().equals("")) && (gost.getMestoOdredista() == null || gost.getMestoOdredista().equals(""))) {
                Session sesija = HibernateUtil.getSessionFactory().openSession();
                sesija.beginTransaction();
                String upit = "SELECT s.mesto, s.brojLinije, s.vremePolaska, p.naziv, s.redniBroj FROM `stajaliste` s, mlinija m, prevoznik p WHERE s.mesto = ? and s.brojLinije = m.brojLinije and m.idPrevoznika=p.idPrevoznika and m.datum = ? and p.naziv = ?";

                SQLQuery sgl = sesija.createSQLQuery(upit);
                sgl.setString(0, gost.getMestoPolazista());
                sgl.setDate(1, gost.getDatum());
                sgl.setString(2, gost.getNazivPrevoznika());

                listas = new ArrayList<>();
                List<Object[]> rs = sgl.list();
                for (int i = 0; i < rs.size(); i++) {
                    Object[] tmp = rs.get(i);
                    Stajalista s = new Stajalista();
                    s.setIme(tmp[0].toString());
                    s.setBrojlinije(Integer.parseInt(tmp[1].toString()));
                     s.setVremepolaska(tmp[2].toString());
                    s.setPrevoznik(gost.getNazivPrevoznika());
                    s.setDatum(gost.getDatum());

                    int rednibr = Integer.parseInt(tmp[4].toString());
                    String upit1 = "SELECT s.mesto, s.redniBroj, s.vremePolaska FROM stajaliste s , mlinija m WHERE s.brojLinije=m.brojLinije and s.redniBroj >= ? and m.brojLinije=?";

                    SQLQuery sql1 = sesija.createSQLQuery(upit1);
                    sql1.setInteger(0, rednibr);
                    sql1.setInteger(1, s.getBrojlinije());
int cnt=0;
                    List<Object[]> rs1 = sql1.list();
                   

                    StringBuilder sb = new StringBuilder();
                    for (int ii = 0; ii < rs1.size(); ii++) {
                        Object[] tmp1 = rs1.get(ii);
                        sb.append(tmp1[0].toString());
                        sb.append("\t");
cnt++;
                    }
                    s.setMedjustanice(sb.toString());
                     if (cnt >= 2) {
                    listas.add(s);
                     }

                }
                return "pretraga";
            } else {
                 if ((gost.getNazivPrevoznika() != null || !gost.getNazivPrevoznika().equals("")) && (gost.getOd() == null || gost.getOd().equals("")) && (gost.getDoo() == null || gost.getDoo().equals("")) && (gost.getMestoPolazista() == null || gost.getMestoPolazista().equals("")) && (gost.getMestoOdredista() != null || !gost.getMestoOdredista().equals(""))) {
                Session sesija = HibernateUtil.getSessionFactory().openSession();
                sesija.beginTransaction();
                String upit = "SELECT s.mesto, s.brojLinije, s.vremePolaska, p.naziv, s.redniBroj FROM `stajaliste` s, mlinija m, prevoznik p WHERE s.mesto = ? and s.brojLinije = m.brojLinije and m.idPrevoznika=p.idPrevoznika and m.datum = ? and p.naziv = ?";

                SQLQuery sgl = sesija.createSQLQuery(upit);
                sgl.setString(0, gost.getMestoOdredista());
                sgl.setDate(1, gost.getDatum());
                sgl.setString(2, gost.getNazivPrevoznika());

                listas = new ArrayList<>();
                List<Object[]> rs = sgl.list();
                for (int i = 0; i < rs.size(); i++) {
                    Object[] tmp = rs.get(i);
                    Stajalista s = new Stajalista();
                    s.setIme(tmp[0].toString());
                    s.setBrojlinije(Integer.parseInt(tmp[1].toString()));

                    s.setPrevoznik(gost.getNazivPrevoznika());
                    s.setDatum(gost.getDatum());

                    int rednibr = Integer.parseInt(tmp[4].toString());
                    String upit1 = "SELECT s.mesto, s.redniBroj, s.vremePolaska FROM stajaliste s , mlinija m WHERE s.brojLinije=m.brojLinije and s.redniBroj <= ? and m.brojLinije=?";

                    SQLQuery sql1 = sesija.createSQLQuery(upit1);
                    sql1.setInteger(0, rednibr);
                    sql1.setInteger(1, s.getBrojlinije());

                    List<Object[]> rs1 = sql1.list();
                    /*
                    Object[] tmp2 = rs1.get(0);
                    String polazak = tmp2[2].toString();
                    s.setVremepolaska(polazak); */
                    String upit2="select * from mlinija where brojLinije= ?";
                   SQLQuery sql2 = sesija.createSQLQuery(upit2);
                    sql2.setInteger(0, s.getBrojlinije());
                    List<Object[]> rs2 = sql2.list();
                   Object[] tmp2=rs2.get(0);
                   String polazak=tmp2[3].toString();
                   s.setVremepolaska(polazak);
 int cnt=0;
                    StringBuilder sb = new StringBuilder();
                    for (int ii = 0; ii < rs1.size(); ii++) {
                        Object[] tmp1 = rs1.get(ii);
                        sb.append(tmp1[0].toString());
                        sb.append("\t");
                        cnt++;

                    }
                    s.setMedjustanice(sb.toString());
if (cnt >= 2)
                    listas.add(s);

                }
                return "pretraga";
            } else {
                      if ((gost.getNazivPrevoznika() != null || !gost.getNazivPrevoznika().equals("")) && (gost.getOd() == null || gost.getOd().equals("")) && (gost.getDoo() == null || gost.getDoo().equals("")) && (gost.getMestoPolazista() != null || !gost.getMestoPolazista().equals("")) && (gost.getMestoOdredista() != null || !gost.getMestoOdredista().equals(""))) {
                    Session sesija = HibernateUtil.getSessionFactory().openSession();
                    sesija.beginTransaction();
                    String upit1="select s1.redniBroj as br1, s1.vremePolaska, s1.brojLinije, s2.redniBroj as br2 from stajaliste s1, stajaliste s2, mlinija m where s1.brojLinije = m.brojLinije and s1.brojLinije=s2.brojLinije and s1.redniBroj < s2.redniBroj and s1.mesto = ? and s2.mesto = ? and m.datum = ?"  ;
                     SQLQuery sql = sesija.createSQLQuery(upit1);
                sql.setString(0, gost.getMestoPolazista());
                sql.setString(1, gost.getMestoOdredista());
                sql.setDate(2, gost.getDatum());
                
                listas = new ArrayList<>();
                List<Object[]> rs = sql.list();
                for (int i = 0; i < rs.size(); i++) {
                    Object[] tmp = rs.get(i);
                    Stajalista s = new Stajalista();
                   
                    s.setBrojlinije(Integer.parseInt(tmp[2].toString()));
                    s.setVremepolaska(tmp[1].toString());

                    
                    s.setDatum(gost.getDatum());

                    int rednibr1 = Integer.parseInt(tmp[0].toString());
                    int rednibr2= Integer.parseInt(tmp[3].toString());
                    String upit = "SELECT s.mesto, s.redniBroj,p.naziv FROM stajaliste s , mlinija m, prevoznik p WHERE m.idPrevoznika = p.idPrevoznika and s.brojLinije=m.brojLinije and s.redniBroj <= ? and s.redniBroj >= ? and m.brojLinije=? and p.naziv = ?";

                    SQLQuery sql1 = sesija.createSQLQuery(upit);
                    sql1.setInteger(0, rednibr2);
                    sql1.setInteger(1, rednibr1);
                    sql1.setInteger(2, s.getBrojlinije());
                    sql1.setString(3, gost.getNazivPrevoznika());

                    List<Object[]> rs1 = sql1.list();
                    
                    s.setPrevoznik(gost.getNazivPrevoznika());
                   
                      int cnt=0;
                    StringBuilder sb = new StringBuilder();
                    for (int ii = 0; ii < rs1.size(); ii++) {
                        Object[] tmp1 = rs1.get(ii);
                        sb.append(tmp1[0].toString());
                        sb.append("\t");
                        cnt++;

                    }
                    s.setMedjustanice(sb.toString());
                     if (cnt >= 2) {
                    listas.add(s);
                     }

                }
                return "pretraga";
                
                
            } else {
            if ((gost.getNazivPrevoznika() == null || gost.getNazivPrevoznika().equals("")) && (gost.getOd() != null || !gost.getOd().equals("")) && (gost.getDoo() != null || !gost.getDoo().equals("")) && (gost.getMestoPolazista() != null || !gost.getMestoPolazista().equals("")) && (gost.getMestoOdredista() == null || gost.getMestoOdredista().equals(""))) {
            Session sesija = HibernateUtil.getSessionFactory().openSession();
            sesija.beginTransaction();
            String upit = "SELECT s.mesto, s.brojLinije, s.vremePolaska, p.naziv, s.redniBroj FROM `stajaliste` s, mlinija m, prevoznik p WHERE s.mesto = ? and s.brojLinije = m.brojLinije and m.idPrevoznika=p.idPrevoznika and m.datum = ? and s.vremePolaska >= ? and s.vremePolaska <= ?";

            SQLQuery sgl = sesija.createSQLQuery(upit);
            sgl.setString(0, gost.getMestoPolazista());
            sgl.setDate(1, gost.getDatum());
            String sati=gost.getOd().substring(0, 2);
            String minuti= gost.getOd().substring(3, 5);
            String sekunde=gost.getOd().substring(6);
            Time vremeod=new Time(Integer.parseInt(sati), Integer.parseInt(minuti), Integer.parseInt(sekunde));
            String sati1=gost.getDoo().substring(0, 2);
            String minuti1= gost.getDoo().substring(3, 5);
            String sekunde1=gost.getDoo().substring(6);
            Time vremedo=new Time(Integer.parseInt(sati1), Integer.parseInt(minuti1), Integer.parseInt(sekunde1));
            sgl.setTime(2, vremeod);
            sgl.setTime(3, vremedo);

            listas = new ArrayList<>();
            List<Object[]> rs = sgl.list();
            for (int i = 0; i < rs.size(); i++) {
                Object[] tmp = rs.get(i);
                Stajalista s = new Stajalista();
                s.setIme(tmp[0].toString());
                s.setBrojlinije(Integer.parseInt(tmp[1].toString()));
                s.setVremepolaska(tmp[2].toString());
                s.setPrevoznik(tmp[3].toString());
                s.setDatum(gost.getDatum());

                int rednibr = Integer.parseInt(tmp[4].toString());
                String upit1 = "SELECT s.mesto, s.redniBroj FROM stajaliste s , mlinija m WHERE s.brojLinije=m.brojLinije and s.redniBroj >= ? and m.brojLinije=?";

                SQLQuery sql1 = sesija.createSQLQuery(upit1);
                sql1.setInteger(0, rednibr);
                sql1.setInteger(1, s.getBrojlinije());
int cnt=0;
                List<Object[]> rs1 = sql1.list();
                StringBuilder sb = new StringBuilder();
                for (int ii = 0; ii < rs1.size(); ii++) {
                    Object[] tmp1 = rs1.get(ii);
                    sb.append(tmp1[0].toString());
                    sb.append("\t");
                    cnt++;
                    

                }
                s.setMedjustanice(sb.toString());
                if (cnt >= 2) {
                listas.add(s);
                }

            }
            return "pretraga";
        } else {
               if ((gost.getNazivPrevoznika() == null || gost.getNazivPrevoznika().equals("")) && (gost.getOd() != null || !gost.getOd().equals("")) && (gost.getDoo() != null || !gost.getDoo().equals("")) && (gost.getMestoPolazista() == null || gost.getMestoPolazista().equals("")) && (gost.getMestoOdredista() != null || !gost.getMestoOdredista().equals(""))) {
                Session sesija = HibernateUtil.getSessionFactory().openSession();
                sesija.beginTransaction();
                String upit = "SELECT s.mesto, s.brojLinije, s.vremePolaska, p.naziv, s.redniBroj FROM `stajaliste` s, mlinija m, prevoznik p WHERE s.mesto = ? and s.brojLinije = m.brojLinije and m.idPrevoznika=p.idPrevoznika and m.datum = ? and s.vremePolaska >= ? and s.vremePolaska <= ?";

                SQLQuery sgl = sesija.createSQLQuery(upit);
                sgl.setString(0, gost.getMestoOdredista());
                sgl.setDate(1, gost.getDatum());
                String sati=gost.getOd().substring(0, 2);
            String minuti= gost.getOd().substring(3, 5);
            String sekunde=gost.getOd().substring(6);
            Time vremeod=new Time(Integer.parseInt(sati), Integer.parseInt(minuti), Integer.parseInt(sekunde));
            String sati1=gost.getDoo().substring(0, 2);
            String minuti1= gost.getDoo().substring(3, 5);
            String sekunde1=gost.getDoo().substring(6);
            Time vremedo=new Time(Integer.parseInt(sati1), Integer.parseInt(minuti1), Integer.parseInt(sekunde1));
            sgl.setTime(2, vremeod);
            sgl.setTime(3, vremedo);

                listas = new ArrayList<>();
                List<Object[]> rs = sgl.list();
                for (int i = 0; i < rs.size(); i++) {
                    Object[] tmp = rs.get(i);
                    Stajalista s = new Stajalista();
                    s.setIme(tmp[0].toString());
                    s.setBrojlinije(Integer.parseInt(tmp[1].toString()));

                    s.setPrevoznik(tmp[3].toString());
                    s.setDatum(gost.getDatum());

                    int rednibr = Integer.parseInt(tmp[4].toString());
                    String upit1 = "SELECT s.mesto, s.redniBroj, s.vremePolaska FROM stajaliste s , mlinija m WHERE s.brojLinije=m.brojLinije and s.redniBroj <= ? and m.brojLinije=?";

                    SQLQuery sql1 = sesija.createSQLQuery(upit1);
                    sql1.setInteger(0, rednibr);
                    sql1.setInteger(1, s.getBrojlinije());

                    List<Object[]> rs1 = sql1.list();
                   /* Object[] tmp2 = rs1.get(0);
                    String polazak = tmp2[2].toString();
                    s.setVremepolaska(polazak); */
                  /* String upit2="SELECT * from mlinija where brojLinije=?";
                   SQLQuery sql2=sesija.createSQLQuery(upit2);
                   sql2.setInteger(0,s.getBrojlinije());
                    List<Object[]> rs2 = sql2.list();
                   Object[] tmp2=rs2.get(0);
                   String polazak=tmp2[3].toString();
                   s.setVremepolaska(polazak); */
                   String upit2="select * from mlinija where brojLinije= ?";
                   SQLQuery sql2 = sesija.createSQLQuery(upit2);
                    sql2.setInteger(0, s.getBrojlinije());
                    List<Object[]> rs2 = sql2.list();
                   Object[] tmp2=rs2.get(0);
                   String polazak=tmp2[3].toString();
                   s.setVremepolaska(polazak);
                   int cnt=0;
                   

                    StringBuilder sb = new StringBuilder();
                    for (int ii = 0; ii < rs1.size(); ii++) {
                        Object[] tmp1 = rs1.get(ii);
                        sb.append(tmp1[0].toString());
                        sb.append("\t");
                        cnt++;

                    }
                    s.setMedjustanice(sb.toString());
                     if (cnt >= 2) {
                    listas.add(s);
                     }

                }
                return "pretraga";
            } else {
                   if ((gost.getNazivPrevoznika() == null || gost.getNazivPrevoznika().equals("")) && (gost.getOd() != null || !gost.getOd().equals("")) && (gost.getDoo() != null || !gost.getDoo().equals("")) && (gost.getMestoPolazista() != null || !gost.getMestoPolazista().equals("")) && (gost.getMestoOdredista() != null || !gost.getMestoOdredista().equals(""))) {
                    Session sesija = HibernateUtil.getSessionFactory().openSession();
                    sesija.beginTransaction();
                    String upit1="select s1.redniBroj as br1, s1.vremePolaska, s1.brojLinije, s2.redniBroj as br2 from stajaliste s1, stajaliste s2, mlinija m where s1.brojLinije = m.brojLinije and s1.brojLinije=s2.brojLinije and s1.redniBroj < s2.redniBroj and s1.mesto = ? and s2.mesto = ? and m.datum = ? and s1.vremePolaska >= ? and s1.vremePolaska <= ?"  ;
                     SQLQuery sql = sesija.createSQLQuery(upit1);
                sql.setString(0, gost.getMestoPolazista());
                sql.setString(1, gost.getMestoOdredista());
                sql.setDate(2, gost.getDatum());
                        String sati=gost.getOd().substring(0, 2);
            String minuti= gost.getOd().substring(3, 5);
            String sekunde=gost.getOd().substring(6);
            Time vremeod=new Time(Integer.parseInt(sati), Integer.parseInt(minuti), Integer.parseInt(sekunde));
            String sati1=gost.getDoo().substring(0, 2);
            String minuti1= gost.getDoo().substring(3, 5);
            String sekunde1=gost.getDoo().substring(6);
            Time vremedo=new Time(Integer.parseInt(sati1), Integer.parseInt(minuti1), Integer.parseInt(sekunde1));
            sql.setTime(3, vremeod);
            sql.setTime(4, vremedo);
                
                listas = new ArrayList<>();
                List<Object[]> rs = sql.list();
                for (int i = 0; i < rs.size(); i++) {
                    Object[] tmp = rs.get(i);
                    Stajalista s = new Stajalista();
                   
                    s.setBrojlinije(Integer.parseInt(tmp[2].toString()));
                    s.setVremepolaska(tmp[1].toString());

                    
                    s.setDatum(gost.getDatum());

                    int rednibr1 = Integer.parseInt(tmp[0].toString());
                    int rednibr2= Integer.parseInt(tmp[3].toString());
                    String upit = "SELECT s.mesto, s.redniBroj,p.naziv FROM stajaliste s , mlinija m, prevoznik p WHERE m.idPrevoznika = p.idPrevoznika and s.brojLinije=m.brojLinije and s.redniBroj <= ? and s.redniBroj >= ? and m.brojLinije=?";

                    SQLQuery sql1 = sesija.createSQLQuery(upit);
                    sql1.setInteger(0, rednibr2);
                    sql1.setInteger(1, rednibr1);
                    sql1.setInteger(2, s.getBrojlinije());

                    List<Object[]> rs1 = sql1.list();
                    
                    Object[] tmp2 = rs1.get(0);
                    String prevoznik = tmp2[2].toString();
                    s.setPrevoznik(prevoznik); 
                    
                   
                   int cnt=0;
                    StringBuilder sb = new StringBuilder();
                    for (int ii = 0; ii < rs1.size(); ii++) {
                        Object[] tmp1 = rs1.get(ii);
                        sb.append(tmp1[0].toString());
                        sb.append("\t");
                        cnt++;

                    }
                    s.setMedjustanice(sb.toString());
                    if (cnt >= 2) {
                    listas.add(s);
                    }

                }
                return "pretraga";
                
                
            } else {
                        if ((gost.getNazivPrevoznika() != null || !gost.getNazivPrevoznika().equals("")) && (gost.getOd() != null || !gost.getOd().equals("")) && (gost.getDoo() != null || !gost.getDoo().equals("")) && (gost.getMestoPolazista() != null || !gost.getMestoPolazista().equals("")) && (gost.getMestoOdredista() == null || gost.getMestoOdredista().equals(""))) {
            Session sesija = HibernateUtil.getSessionFactory().openSession();
            sesija.beginTransaction();
            String upit = "SELECT s.mesto, s.brojLinije, s.vremePolaska, p.naziv, s.redniBroj FROM `stajaliste` s, mlinija m, prevoznik p WHERE s.mesto = ? and s.brojLinije = m.brojLinije and m.idPrevoznika=p.idPrevoznika and m.datum = ? and s.vremePolaska >= ? and s.vremePolaska <= ? and p.naziv= ?";

            SQLQuery sgl = sesija.createSQLQuery(upit);
            sgl.setString(0, gost.getMestoPolazista());
            sgl.setDate(1, gost.getDatum());
            String sati=gost.getOd().substring(0, 2);
            String minuti= gost.getOd().substring(3, 5);
            String sekunde=gost.getOd().substring(6);
            Time vremeod=new Time(Integer.parseInt(sati), Integer.parseInt(minuti), Integer.parseInt(sekunde));
            String sati1=gost.getDoo().substring(0, 2);
            String minuti1= gost.getDoo().substring(3, 5);
            String sekunde1=gost.getDoo().substring(6);
            Time vremedo=new Time(Integer.parseInt(sati1), Integer.parseInt(minuti1), Integer.parseInt(sekunde1));
            sgl.setTime(2, vremeod);
            sgl.setTime(3, vremedo);
            sgl.setString(4, gost.getNazivPrevoznika());

            listas = new ArrayList<>();
            List<Object[]> rs = sgl.list();
            for (int i = 0; i < rs.size(); i++) {
                Object[] tmp = rs.get(i);
                Stajalista s = new Stajalista();
                s.setIme(tmp[0].toString());
                s.setBrojlinije(Integer.parseInt(tmp[1].toString()));
                s.setVremepolaska(tmp[2].toString());
                s.setPrevoznik(gost.getNazivPrevoznika());
                s.setDatum(gost.getDatum());

                int rednibr = Integer.parseInt(tmp[4].toString());
                String upit1 = "SELECT s.mesto, s.redniBroj FROM stajaliste s , mlinija m WHERE s.brojLinije=m.brojLinije and s.redniBroj >= ? and m.brojLinije=?";

                SQLQuery sql1 = sesija.createSQLQuery(upit1);
                sql1.setInteger(0, rednibr);
                sql1.setInteger(1, s.getBrojlinije());
int cnt=0;
                List<Object[]> rs1 = sql1.list();
                StringBuilder sb = new StringBuilder();
                for (int ii = 0; ii < rs1.size(); ii++) {
                    Object[] tmp1 = rs1.get(ii);
                    sb.append(tmp1[0].toString());
                    sb.append("\t");
                    cnt++;

                }
                s.setMedjustanice(sb.toString());
             if (cnt >= 2) {
                listas.add(s);
             }

            }
            return "pretraga";
                   } else {
                            if ((gost.getNazivPrevoznika() != null || !gost.getNazivPrevoznika().equals("")) && (gost.getOd() != null || !gost.getOd().equals("")) && (gost.getDoo() != null || !gost.getDoo().equals("")) && (gost.getMestoPolazista() == null || gost.getMestoPolazista().equals("")) && (gost.getMestoOdredista() != null || !gost.getMestoOdredista().equals(""))) {
                Session sesija = HibernateUtil.getSessionFactory().openSession();
                sesija.beginTransaction();
                String upit = "SELECT s.mesto, s.brojLinije, s.vremePolaska, p.naziv, s.redniBroj FROM `stajaliste` s, mlinija m, prevoznik p WHERE s.mesto = ? and s.brojLinije = m.brojLinije and m.idPrevoznika=p.idPrevoznika and m.datum = ? and s.vremePolaska >= ? and s.vremePolaska <= ? and p.naziv= ?";

                SQLQuery sgl = sesija.createSQLQuery(upit);
                sgl.setString(0, gost.getMestoOdredista());
                sgl.setDate(1, gost.getDatum());
                String sati=gost.getOd().substring(0, 2);
            String minuti= gost.getOd().substring(3, 5);
            String sekunde=gost.getOd().substring(6);
            Time vremeod=new Time(Integer.parseInt(sati), Integer.parseInt(minuti), Integer.parseInt(sekunde));
            String sati1=gost.getDoo().substring(0, 2);
            String minuti1= gost.getDoo().substring(3, 5);
            String sekunde1=gost.getDoo().substring(6);
            Time vremedo=new Time(Integer.parseInt(sati1), Integer.parseInt(minuti1), Integer.parseInt(sekunde1));
            sgl.setTime(2, vremeod);
            sgl.setTime(3, vremedo);
            sgl.setString(4, gost.getNazivPrevoznika());

                listas = new ArrayList<>();
                List<Object[]> rs = sgl.list();
                for (int i = 0; i < rs.size(); i++) {
                    Object[] tmp = rs.get(i);
                    Stajalista s = new Stajalista();
                    s.setIme(tmp[0].toString());
                    s.setBrojlinije(Integer.parseInt(tmp[1].toString()));

                    s.setPrevoznik(tmp[3].toString());
                    s.setDatum(gost.getDatum());

                    int rednibr = Integer.parseInt(tmp[4].toString());
                    String upit1 = "SELECT s.mesto, s.redniBroj, s.vremePolaska FROM stajaliste s , mlinija m WHERE s.brojLinije=m.brojLinije and s.redniBroj <= ? and m.brojLinije=?";

                    SQLQuery sql1 = sesija.createSQLQuery(upit1);
                    sql1.setInteger(0, rednibr);
                    sql1.setInteger(1, s.getBrojlinije());

                    List<Object[]> rs1 = sql1.list();
                   /* Object[] tmp2 = rs1.get(0);
                    String polazak = tmp2[2].toString();
                    s.setVremepolaska(polazak); */
                  /* String upit2="SELECT * from mlinija where brojLinije=?";
                   SQLQuery sql2=sesija.createSQLQuery(upit2);
                   sql2.setInteger(0,s.getBrojlinije());
                    List<Object[]> rs2 = sql2.list();
                   Object[] tmp2=rs2.get(0);
                   String polazak=tmp2[3].toString();
                   s.setVremepolaska(polazak); */
                   String upit2="select * from mlinija where brojLinije= ?";
                   SQLQuery sql2 = sesija.createSQLQuery(upit2);
                    sql2.setInteger(0, s.getBrojlinije());
                    List<Object[]> rs2 = sql2.list();
                   Object[] tmp2=rs2.get(0);
                   String polazak=tmp2[3].toString();
                   s.setVremepolaska(polazak);
                   
                   int cnt=0;

                    StringBuilder sb = new StringBuilder();
                    for (int ii = 0; ii < rs1.size(); ii++) {
                        Object[] tmp1 = rs1.get(ii);
                        sb.append(tmp1[0].toString());
                        sb.append("\t");
cnt++;
                    }
                    s.setMedjustanice(sb.toString());
                    if (cnt >= 2) {
                    listas.add(s);
                    }

                }
                return "pretraga";
            } else {
                        if ((gost.getNazivPrevoznika() != null || !gost.getNazivPrevoznika().equals("")) && (gost.getOd() != null || !gost.getOd().equals("")) && (gost.getDoo() != null || !gost.getDoo().equals("")) && (gost.getMestoPolazista() != null || !gost.getMestoPolazista().equals("")) && (gost.getMestoOdredista() != null || !gost.getMestoOdredista().equals(""))) {
                    Session sesija = HibernateUtil.getSessionFactory().openSession();
                    sesija.beginTransaction();
                    String upit1="select s1.redniBroj as br1, s1.vremePolaska, s1.brojLinije, s2.redniBroj as br2 from stajaliste s1, stajaliste s2, mlinija m where s1.brojLinije = m.brojLinije and s1.brojLinije=s2.brojLinije and s1.redniBroj < s2.redniBroj and s1.mesto = ? and s2.mesto = ? and m.datum = ? and s1.vremePolaska >= ? and s1.vremePolaska <= ?"  ;
                     SQLQuery sql = sesija.createSQLQuery(upit1);
                sql.setString(0, gost.getMestoPolazista());
                sql.setString(1, gost.getMestoOdredista());
                sql.setDate(2, gost.getDatum());
                        String sati=gost.getOd().substring(0, 2);
            String minuti= gost.getOd().substring(3, 5);
            String sekunde=gost.getOd().substring(6);
            Time vremeod=new Time(Integer.parseInt(sati), Integer.parseInt(minuti), Integer.parseInt(sekunde));
            String sati1=gost.getDoo().substring(0, 2);
            String minuti1= gost.getDoo().substring(3, 5);
            String sekunde1=gost.getDoo().substring(6);
            Time vremedo=new Time(Integer.parseInt(sati1), Integer.parseInt(minuti1), Integer.parseInt(sekunde1));
            sql.setTime(3, vremeod);
            sql.setTime(4, vremedo);
                
                listas = new ArrayList<>();
                List<Object[]> rs = sql.list();
                for (int i = 0; i < rs.size(); i++) {
                    Object[] tmp = rs.get(i);
                    Stajalista s = new Stajalista();
                   
                    s.setBrojlinije(Integer.parseInt(tmp[2].toString()));
                    s.setVremepolaska(tmp[1].toString());

                    
                    s.setDatum(gost.getDatum());

                    int rednibr1 = Integer.parseInt(tmp[0].toString());
                    int rednibr2= Integer.parseInt(tmp[3].toString());
                    String upit = "SELECT s.mesto, s.redniBroj,p.naziv FROM stajaliste s , mlinija m, prevoznik p WHERE m.idPrevoznika = p.idPrevoznika and s.brojLinije=m.brojLinije and s.redniBroj <= ? and s.redniBroj >= ? and m.brojLinije=? and p.naziv = ?";

                    SQLQuery sql1 = sesija.createSQLQuery(upit);
                    sql1.setInteger(0, rednibr2);
                    sql1.setInteger(1, rednibr1);
                    sql1.setInteger(2, s.getBrojlinije());
                    sql1.setString(3, gost.getNazivPrevoznika());

                    List<Object[]> rs1 = sql1.list();
                    
                
                    s.setPrevoznik(gost.getNazivPrevoznika()); 
                    
                   int cnt=0;
                 
                    StringBuilder sb = new StringBuilder();
                    for (int ii = 0; ii < rs1.size(); ii++) {
                        Object[] tmp1 = rs1.get(ii);
                        sb.append(tmp1[0].toString());
                        sb.append("\t");
                          cnt++;
                    }
                    s.setMedjustanice(sb.toString());
                   if (cnt > 1 ) {
                    listas.add(s);
                   }

                }
                return "pretraga";
                
                
            }        
                            }
                        }
               }
            }
                      }
                 }
                }
                
        
        return null;
    }
}
        }
    }
        
}
}
   
}