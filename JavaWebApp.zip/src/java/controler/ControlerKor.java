/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import config.HibernateUtil;
import hibclass.Autobus;
import hibclass.Glinija;
import hibclass.Korisnik;
import hibclass.Rezervacija;
import hibclass.Vozac;
import java.io.Serializable;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.primefaces.model.map.DefaultMapModel;
import org.primefaces.model.map.LatLng;
import org.primefaces.model.map.MapModel;
import org.primefaces.model.map.Marker;
import util.DetaljiLinija;
import util.MedjLinija;

/**
 *
 * @author Tijana
 */
@Named(value="con")
@SessionScoped
public class ControlerKor implements Serializable{
    private String staniceG;
    private String uname;
    private String password;
    private String kmessage;
    private String regm;
    private final String adminuname = "drazen";
    private final String adminpass = "Sifra123";
    private Korisnik kor= new Korisnik();
    private String zanimanje;
    private String lozinkam;
    private ArrayList<Glinija> glista= new ArrayList<>();
    private ArrayList<Glinija> filterglista;
    private String stajaliste;
    private ArrayList<DetaljiLinija> dlista=new ArrayList<>();
    private ArrayList<DetaljiLinija> filterdlista;
    private String redvoznje="";
    private ArrayList<MedjLinija> mlista= new ArrayList<>();
    private ArrayList<MedjLinija> filtermlista;
    private ArrayList<Autobus> alista=new ArrayList<>();
    private ArrayList<Vozac> vlista=new ArrayList<>();
    private ArrayList<String> slike= new ArrayList<>();
    private MapModel advancedModel;
    private String rezmessage;
    private String drezmessage;
    private MedjLinija medj;
    private ArrayList<Rezervacija> rlista= new ArrayList<>();
    private final int nezaposlenCenaMes = 2500;
    private final int zaposlenCenaMes = 3500;
    private final int studentCenaMes = 1200;
    private final int invalidCenaMes = 500;
    private final int penzionerCenaMes = 1000;
    private final int nezaposlenCenaGod = 12000;
    private final int zaposlenCenaGod = 15000;
    private final int studentCenaGod = 7500;
    private final int invalidCenaGod = 3500;
    private final int penzionerCenaGod = 7000;
    private int mesecna = 0;
    private int godisnja = 0;
    private String karticamess;
    private ArrayList<String> poruke=new ArrayList<>();
    private ArrayList<String> filterporuke;
    
    public ControlerKor() {
    }

    public ArrayList<String> getFilterporuke() {
        return filterporuke;
    }

    public void setFilterporuke(ArrayList<String> filterporuke) {
        this.filterporuke = filterporuke;
    }

    
    
    public ArrayList<String> getPoruke() {
        return poruke;
    }

    public void setPoruke(ArrayList<String> poruke) {
        this.poruke = poruke;
    }
    
    

    public String getAdminuname() {
        return adminuname;
    }

    public String getAdminpass() {
        return adminpass;
    }
    
    

    public String getKarticamess() {
        return karticamess;
    }

    public void setKarticamess(String karticamess) {
        this.karticamess = karticamess;
    }
    

    public String getZanimanje() {
        return zanimanje;
    }

    public void setZanimanje(String zanimanje) {
        this.zanimanje = zanimanje;
    }

    
    public int getMesecna() {
        return mesecna;
    }

    public void setMesecna(int mesecna) {
        this.mesecna = mesecna;
    }

    public int getGodisnja() {
        return godisnja;
    }

    public void setGodisnja(int godisnja) {
        this.godisnja = godisnja;
    }

    
    
    public int getNezaposlenCenaMes() {
        return nezaposlenCenaMes;
    }

    public int getZaposlenCenaMes() {
        return zaposlenCenaMes;
    }

    public int getStudentCenaMes() {
        return studentCenaMes;
    }

    public int getInvalidCenaMes() {
        return invalidCenaMes;
    }

    public int getPenzionerCenaMes() {
        return penzionerCenaMes;
    }

    public int getNezaposlenCenaGod() {
        return nezaposlenCenaGod;
    }

    public int getZaposlenCenaGod() {
        return zaposlenCenaGod;
    }

    public int getStudentCenaGod() {
        return studentCenaGod;
    }

    public int getInvalidCenaGod() {
        return invalidCenaGod;
    }

    public int getPenzionerCenaGod() {
        return penzionerCenaGod;
    }
    
    

    public ArrayList<Rezervacija> getRlista() {
        return rlista;
    }

    public void setRlista(ArrayList<Rezervacija> rlista) {
        this.rlista = rlista;
    }
    
    

    public String getDrezmessage() {
        return drezmessage;
    }

    public void setDrezmessage(String drezmessage) {
        this.drezmessage = drezmessage;
    }

    
    
    
    public MedjLinija getMedj() {
        return medj;
    }

    public void setMedj(MedjLinija medj) {
        this.medj = medj;
    }
    
    

    public String getRezmessage() {
        return rezmessage;
    }

    public void setRezmessage(String rezmessage) {
        this.rezmessage = rezmessage;
    }
    
    

    public MapModel getAdvancedModel() {
        return advancedModel;
    }

    public void setAdvancedModel(MapModel advancedModel) {
        this.advancedModel = advancedModel;
    }
    
    

    public ArrayList<String> getSlike() {
        return slike;
    }

    public void setSlike(ArrayList<String> slike) {
        this.slike = slike;
    }
    
    

    public ArrayList<Vozac> getVlista() {
        return vlista;
    }

    public void setVlista(ArrayList<Vozac> vlista) {
        this.vlista = vlista;
    }
    
    

    public ArrayList<Autobus> getAlista() {
        return alista;
    }

    public void setAlista(ArrayList<Autobus> alista) {
        this.alista = alista;
    }
    
    

    public ArrayList<MedjLinija> getFiltermlista() {
        return filtermlista;
    }

    public void setFiltermlista(ArrayList<MedjLinija> filtermlista) {
        this.filtermlista = filtermlista;
    }
    
    

    public ArrayList<MedjLinija> getMlista() {
        return mlista;
    }

    public void setMlista(ArrayList<MedjLinija> mlista) {
        this.mlista = mlista;
    }
    

    public String getRedvoznje() {
        return redvoznje;
    }

    public void setRedvoznje(String redvoznje) {
        this.redvoznje = redvoznje;
    }
    

    public ArrayList<DetaljiLinija> getFilterdlista() {
        return filterdlista;
    }

    public void setFilterdlista(ArrayList<DetaljiLinija> filterdlista) {
        this.filterdlista = filterdlista;
    }
    

    public ArrayList<DetaljiLinija> getDlista() {
        return dlista;
    }

    public void setDlista(ArrayList<DetaljiLinija> dlista) {
        this.dlista = dlista;
    }
    
    

    public String getStajaliste() {
        return stajaliste;
    }

    public void setStajaliste(String stajaliste) {
        this.stajaliste = stajaliste;
    }
    
    

    public ArrayList<Glinija> getFilterglista() {
        return filterglista;
    }

    public void setFilterglista(ArrayList<Glinija> filterglista) {
        this.filterglista = filterglista;
    }
    
    public ArrayList<Glinija> getGlista() {
        return glista;
    }

    public void setGlista(ArrayList<Glinija> glista) {
        this.glista = glista;
    }
    
    

    public String getLozinkam() {
        return lozinkam;
    }

    public void setLozinkam(String lozinkam) {
        this.lozinkam = lozinkam;
    }
    


    
    public String getRegm() {
        return regm;
    }

    public void setRegm(String regm) {
        this.regm = regm;
    }

    public Korisnik getKor() {
        return kor;
    }

    public void setKor(Korisnik kor) {
        this.kor = kor;
    }
    

  
    public String getKmessage() {
        return kmessage;
    }

    public void setKmessage(String kmessage) {
        this.kmessage = kmessage;
    }
    

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String login(){
        kmessage="";
        if (uname.equals(adminuname)){
            if(!(password.equals(adminpass))){
                 kmessage="Pogresna lozinka!";
                 return null;
           
            }
            return "admin";
        }
        Session sesija=HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        
        Korisnik k=(Korisnik) sesija.get(Korisnik.class, uname);
        
        if(k == null){
            kmessage="Uneto korisnicko ime ne postoji!";
            sesija.close();
            return null;
        }
        if(k.getFlagReg() == 0){
        if(!(k.getPassword().equals(password))){
            
            kmessage="Pogresna lozinka!";
            sesija.close();
            return null;
        }
        
         String upit="select * from poruka where uname= ? or uname='admin' order by id desc";
         SQLQuery sql=sesija.createSQLQuery(upit);
         sql.setString(0, uname);
         poruke=new ArrayList<>();
         List<Object[]> rs=sql.list();
          for (int i = 0; i < rs.size(); i++) {
                    Object[] tmp = rs.get(i);
                    String poruka=tmp[2].toString();
                    poruke.add(poruka);
          }
        zanimanje=k.getZanimanje();
        sesija.close();
        return "korisnik";
        }
        kmessage="I dalje vas zahtev nije prihvacen!";
        sesija.close();
        return null;
    }
    
    public String registracija(){
        regm="";
        String pass=kor.getPassword();
        int mala=0;
        int velika=0;
        int numerik=0;
        int specznak=0;
        
        char tekuca=pass.charAt(0);
        int cnt=1;
        for(int i=0; i<pass.length();i++){
            char c=pass.charAt(i);
            if(c>= 'A' && c<= 'Z' ) { velika++;
            } else {
                if(c>= 'a' && c<= 'z') {
                    mala++;
                }else {
                    if(c>= '0' && c<='9'){
                        numerik++;
                    }
                }
            }
            if (i>0) {
                if (tekuca == c) {
                    cnt++;
                    if (cnt > 2) {
                        lozinkam="Sifra ne sme imati vise od dva uzastopna ista znaka!";
                        return null;
                    }
                } else {
                    tekuca=c;
                    cnt=1;
                }
            }
        }
        if (velika < 1){ lozinkam="Sifra mora imati  bar jedno veliko slovo!"; return null; }
        if (mala < 3 ){lozinkam="Sifra mora imati bar tri mala slova!"; return null; }
        if (numerik + specznak < 1) { lozinkam="Sifra mora imati bar jednu cifru ili specijalni znak!"; return null; }
        Session sesija=HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        kor.setFlagReg(1);
        sesija.save(kor);
        sesija.getTransaction().commit();
        sesija.close();
        regm="Poslat zahtev za registrovanje!";
        return "registracija1";
    }
    
    public String pretragaG(){
        Session sesija=HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit="select * from glinija";
        SQLQuery sql = sesija.createSQLQuery(upit);
        glista= new ArrayList<>();
        List<Object[]> rs=sql.list();
        for (int i = 0; i < rs.size(); i++) {
                Object[] tmp = rs.get(i);
                Glinija g= new Glinija();
                g.setBrojLinije(tmp[2].toString());
                g.setPocetnoOdrediste(tmp[0].toString());
                g.setKrajnjeOdrediste(tmp[1].toString());
                glista.add(g);
        }
        
        sesija.close();
        return "gradske";
    }
    
     public String vididetalje(Glinija i){
         String broj=i.getBrojLinije();
         Session sesija=HibernateUtil.getSessionFactory().openSession();
         sesija.beginTransaction();
         
          SQLQuery sql1x=sesija.createSQLQuery("select * from gstanica where brojLinije = ?");
         sql1x.setString(0, i.getBrojLinije() );
         staniceG="";
         List<Object[]> rez=sql1x.list();
         for (Object[] x : rez) {
             staniceG+=x[1].toString() + "   ";
            
         }
         
         
         
         
         String upit="SELECT redVoznje from glinija where brojLinije=?";
         SQLQuery sql=sesija.createSQLQuery(upit);
         sql.setString(0,broj);
         Object rs=sql.list();
     //    Object[] tmp=rs.get(0);
          redvoznje=rs.toString();
         
         String upit1="select v.ime, v.prezime, v.datumRodjenja, v.godinaPocetka from gvozac g, vozac v where g.idVozaca=v.id and g.brojLinije = ?";
         SQLQuery sql1=sesija.createSQLQuery(upit1);
         dlista=new ArrayList<>();
         sql1.setString(0,broj);
          List<Object[]> rs1=sql1.list();
            for (int ii = 0; ii < rs1.size(); ii++) {
                    Object[] tmp1 = rs1.get(ii);
                    DetaljiLinija d=new DetaljiLinija();
                    d.setIme(tmp1[0].toString());
                    d.setPrezime(tmp1[1].toString());
                    d.setDatumRodjenja((Date)tmp1[2]);
                    d.setGodinap(tmp1[3].toString());
                    d.setRedvoznje(redvoznje);
                    dlista.add(d);
            }
            sesija.close();
         return "gdetalji";
         
     }
     
     public String pretraziM(){
         Session sesija=HibernateUtil.getSessionFactory().openSession();
         sesija.beginTransaction();
         String upit="select p.naziv, m.pocetnoOdrediste, m.krajnjeOdrediste, m.datum, m.vremePolaska, m.brojLinije from mlinija m, prevoznik p where p.idPrevoznika=m.idPrevoznika";
         SQLQuery sql=sesija.createSQLQuery(upit);
         mlista=new ArrayList<>();
        List<Object[]> rs=sql.list();
          for (int i = 0; i < rs.size(); i++) {
                    Object[] tmp = rs.get(i);
                    MedjLinija m= new MedjLinija();
                    m.setPrevoznik(tmp[0].toString());
                    m.setPolazak(tmp[1].toString());
                    m.setOdlazak(tmp[2].toString());
                    m.setDatum((Date)tmp[3]);
                    m.setVreme(tmp[4].toString());
                    m.setBrojl((Integer)tmp[5]);
                    
                    
                    int brojl=(Integer)tmp[5];
                    
                    
                    String upit1="select s.mesto, s.brojLinije from stajaliste s, mlinija m where m.brojLinije = s.brojLinije and m.brojLinije = ?";
                      SQLQuery sql1 = sesija.createSQLQuery(upit1);
                      sql1.setInteger(0, brojl);
                       List<Object[]> rs1 = sql1.list();
                StringBuilder sb = new StringBuilder();
                for (int ii = 0; ii < rs1.size(); ii++) {
                    Object[] tmp1 = rs1.get(ii);
                    sb.append(tmp1[0].toString());
                    sb.append("\t");

                }
                  m.setMedjustanice(sb.toString());
                           
                    
                    mlista.add(m);
                    
                    
          }
          sesija.close();
         return "medjugradske";
     }
     
     
     public String mdetalji(MedjLinija i){
         medj=new MedjLinija();
         medj=i;
         Session sesija= HibernateUtil.getSessionFactory().openSession();
         sesija.beginTransaction();
         String upit="select a.model, a.marka, a.kapacitet from autobus a, mautobus m where m.idB=a.id and m.brojLinije= ?";
         SQLQuery sql = sesija.createSQLQuery(upit);
         sql.setInteger(0,i.getBrojl());
         alista=new ArrayList<>();
          List<Object[]> rs=sql.list();
          for (int ii = 0; ii < rs.size(); ii++) {
                    Object[] tmp = rs.get(ii);
                    Autobus a=new Autobus();
                    a.setModel(tmp[0].toString());
                    a.setMarka(tmp[1].toString());
                    a.setKapacitet((Integer)tmp[2]);
                    alista.add(a);
          }
         
          String upit1="select v.ime, v.prezime, v.datumRodjenja, v.godinaPocetka from vozac v, mvozac m where m.idVozaca=v.id and m.brojLinije= ?";
          SQLQuery sql1=sesija.createSQLQuery(upit1);
          sql1.setInteger(0, i.getBrojl());
          vlista= new ArrayList<>();
           List<Object[]> rs1=sql1.list();
          for (int ii = 0; ii < rs1.size(); ii++) {
                    Object[] tmp1 = rs1.get(ii);
                    Vozac v=new Vozac();
                    v.setIme(tmp1[0].toString());
                    v.setPrezime(tmp1[1].toString());
                    v.setDatumRodjenja((Date)tmp1[2]);
                    v.setGodinaPocetka((Integer)tmp1[3]);
                    vlista.add(v);
          }
          
          String upit2="select s.slika, s.idBusa from slika s, mautobus m where m.idB = s.idBusa and m.brojLinije=?";
          SQLQuery sql2=sesija.createSQLQuery(upit2);
          sql2.setInteger(0, i.getBrojl());
          slike= new ArrayList<>();
           List<Object[]> rs2=sql2.list();
          for (int ii = 0; ii < rs2.size(); ii++) {
                    Object[] tmp2 = rs2.get(ii);
                    String s=tmp2[0].toString();
                    slike.add(s);
          }
           advancedModel = new DefaultMapModel();
          String upit3="select * from stajaliste where brojLinije=?";
          SQLQuery sql3=sesija.createSQLQuery(upit3);
          sql3.setInteger(0, i.getBrojl());
           List<Object[]> rs3 = sql3.list();

        for (int ii = 0; ii < rs3.size(); ii++) {
                    Object[] tmp = rs3.get(ii);
            double c1 = Double.parseDouble(tmp[0].toString());
            double c2 = Double.parseDouble(tmp[1].toString());
            LatLng coord1 = new LatLng(c1, c2);
            if (i.getPolazak().equals(tmp[3].toString())) {
                advancedModel.addOverlay(new Marker(coord1, tmp[3].toString(), "konyaalti.png", "http://maps.google.com/mapfiles/ms/micons/blue-dot.png"));
            } else {
                if (i.getOdlazak().equals(tmp[3].toString())) {
                    advancedModel.addOverlay(new Marker(coord1, tmp[3].toString(), "kaleici.png", "http://maps.google.com/mapfiles/ms/micons/green-dot.png"));

                } else {
                    advancedModel.addOverlay(new Marker(coord1, tmp[3].toString(), "karaalioglu.png", "http://maps.google.com/mapfiles/ms/micons/yellow-dot.png"));
                }
            }
        }
          sesija.close();
         return "mdetalji";
     }
     
     public String rezervisi(MedjLinija i){
         rezmessage="";
         Session sesija=HibernateUtil.getSessionFactory().openSession();
         sesija.beginTransaction();
         try{
         String  upit="Insert into rezervacija values (?,?,?,?,?);";
         SQLQuery sql=sesija.createSQLQuery(upit);
         sql.setInteger(0, i.getBrojl());
         sql.setString(1, uname);
         sql.setDate(2, i.getDatum());
         sql.setInteger(3, 1);
         sql.setInteger(4, 1);
         sql.executeUpdate();
         sesija.getTransaction().commit();
         }catch (Exception e){
             rezmessage="Vec ste poslali zahtev za rezervaciju za ovu liniju!";
         sesija.close();
         
         return null;
         }
         rezmessage="Uspesno ste poslali zahtev za rezervaciju!";
         sesija.close();
         
         return null;
     }
     
     public String drezervisi(){
         drezmessage="";
         Session sesija=HibernateUtil.getSessionFactory().openSession();
         sesija.beginTransaction();
         String  upit="Insert into rezervacija values (?,?,?,?,?);";
         SQLQuery sql=sesija.createSQLQuery(upit);
         sql.setInteger(0, medj.getBrojl());
         sql.setString(1, uname);
         sql.setDate(2, medj.getDatum());
         sql.setInteger(3, 1);
         sql.setInteger(4, 1);
         sql.executeUpdate();
         sesija.getTransaction().commit();
         drezmessage="Uspesno ste poslali zahtev za rezervaciju!";
         sesija.close();
         return null;
     }
     
     public String vidirez(){
         Session sesija=HibernateUtil.getSessionFactory().openSession();
         sesija.beginTransaction();
         String  upit="select * from rezervacija where zahtev=0 and uname = ?";
         SQLQuery sql=sesija.createSQLQuery(upit);
         sql.setString(0, uname);
         rlista=new ArrayList<>();
          List<Object[]> rs=sql.list();
          for (int ii = 0; ii < rs.size(); ii++) {
                    Object[] tmp = rs.get(ii);
                    Rezervacija r=new Rezervacija();
                    r.getId().setBrojLinije((Integer)tmp[0]);
                    r.getId().setDatum((Date)tmp[2]);
                    r.setBroj((Integer)tmp[3]);
                    rlista.add(r);
         
          }
          sesija.close();
         return "rezervacije";
     }
     
     public String otkazirez(Rezervacija i){
         rezmessage="";
         Session sesija=HibernateUtil.getSessionFactory().openSession();
         sesija.beginTransaction();
      //   String  upit="select * from mlinija where datum= ?  and brojLinije= ? and ( (datum > CURRENT_DATE) or (datum = CURRENT_DATE and (ADDTIME(CURRENT_TIME,'1:0:0')) < vremePolaska ) )";
       String upit="select * from mlinija where datum= ? and brojLinije= ? and ( (datum > CURRENT_DATE) or (datum = CURRENT_DATE and (ADDTIME(CURRENT_TIME,'1:0:0')) < vremePolaska ) )";
      SQLQuery sql=sesija.createSQLQuery(upit);
         sql.setDate(0,i.getId().getDatum());
         sql.setInteger(1, i.getId().getBrojLinije());
         List<Object[]> rs=sql.list();
         if(!rs.isEmpty()){
             String upit1="DELETE FROM `rezervacija` WHERE datum= ? and brojLinije= ?";
             SQLQuery sql1=sesija.createSQLQuery(upit1);
             sql1.setDate(0, i.getId().getDatum());
             sql1.setInteger(1, i.getId().getBrojLinije());
             sql1.executeUpdate();
             sesija.getTransaction().commit();
             rlista.remove(i);
             rezmessage="Uspesno otkazana rezervacija!";
         } else {
             rezmessage="Nije moguce otkazati rezervaciju!";
         }
         
         sesija.close();
         return null;
     }
     
     public String kupiKartice(){
         String kategorija = zanimanje;
         if(kategorija.equals("nezaposlen")) {
             mesecna=nezaposlenCenaMes;
             godisnja=nezaposlenCenaGod;
             return "kartice";
         }
         if(kategorija.equals("zaposlen")) {
             mesecna=zaposlenCenaMes;
             godisnja=zaposlenCenaGod;
             return "kartice";
         }
          
         if(kategorija.equals("student")) {
             mesecna=studentCenaMes;
             godisnja=studentCenaGod;
             return "kartice";
         }
         
         if(kategorija.equals("lice sa invaliditetom")) {
             mesecna=invalidCenaMes;
             godisnja=invalidCenaGod;
             return "kartice";
         }
         
         if(kategorija.equals("penzioner")) {
             mesecna=penzionerCenaMes;
             godisnja=penzionerCenaGod;
             return "kartice";
         }
         
         return null;
     }
     
     public String kupimesecnu(){
         karticamess="";
         try{
        Session sesija=HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit="insert into kartica values(?,?,?);";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, "mesecna");
        sql.setInteger(1, 1);
        sql.setString(2, uname);
        sql.executeUpdate();
        sesija.getTransaction().commit();
        sesija.close();
         } catch(Exception e){
            karticamess="Vec ste kupili mesecnu/godisnju karticu!";
            return null;
        }
        
        karticamess="Uspesno ste poslali zahtev za kupovinu mesecne kartice!";
        
         return null;
     }
     
     public String kupigodisnju(){
         karticamess="";
         try{
        Session sesija=HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit="insert into kartica values(?,?,?);";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, "godisnja");
        sql.setInteger(1, 1);
        sql.setString(2, uname);
        sql.executeUpdate();
        sesija.getTransaction().commit();
        sesija.close();
         } catch (Exception e){
             karticamess="Vec ste kupili mesecnu/godisnju karticu!";
             return null;
         }
        karticamess="Uspesno ste poslali zahtev za kupovinu godisnje kartice!";
        
         return null;
         
     }
     
     
     public void nadjilinije(){
        Session sesija=HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit="select g.brojLinije, g.pocetnoOdrediste, g.krajnjeOdrediste from glinija g, gstanica s where g.brojLinije=s.brojLinije and s.mesto = ?";
         SQLQuery sql = sesija.createSQLQuery(upit);
         sql.setString(0, stajaliste);
        glista= new ArrayList<>();
        List<Object[]> rs=sql.list();
        for (int i = 0; i < rs.size(); i++) {
                Object[] tmp = rs.get(i);
                Glinija g= new Glinija();
                g.setBrojLinije(tmp[0].toString());
                g.setPocetnoOdrediste(tmp[1].toString());
                g.setKrajnjeOdrediste(tmp[2].toString());
                glista.add(g);
        }
        
        sesija.close();
     }
     
     public String logout(){
         FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
         return "index";
     }
     
     public String obrisi(String i){
        Session sesija=HibernateUtil.getSessionFactory().openSession();
        sesija.beginTransaction();
        String upit="delete from poruka where sadrzaj=? and uname= ?";
        SQLQuery sql = sesija.createSQLQuery(upit);
        sql.setString(0, i);
        sql.setString(1, uname);
        poruke.remove(i);
        sql.executeUpdate();
        sesija.getTransaction().commit();
        sesija.close();
        return null;
     }

    public String getStaniceG() {
        return staniceG;
    }

    public void setStaniceG(String staniceG) {
        this.staniceG = staniceG;
    }
     
     
}
