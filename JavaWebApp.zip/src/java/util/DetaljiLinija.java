/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.util.Date;

/**
 *
 * @author User
 */
public class DetaljiLinija {
    private String redvoznje;
    private String ime;
    private String prezime;
    private Date datumRodjenja;
    private String godinap;

    public String getRedvoznje() {
        return redvoznje;
    }

    public void setRedvoznje(String redvoznje) {
        this.redvoznje = redvoznje;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public Date getDatumRodjenja() {
        return datumRodjenja;
    }

    public void setDatumRodjenja(Date datumRodjenja) {
        this.datumRodjenja = datumRodjenja;
    }

    public String getGodinap() {
        return godinap;
    }

    public void setGodinap(String godinap) {
        this.godinap = godinap;
    }
    
}
