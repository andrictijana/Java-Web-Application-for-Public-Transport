/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.util.Date;

/**
 *
 * @author User
 */
public class MedjLinija {
    private String prevoznik;
    private String polazak;
    private String odlazak;
    private Date datum;
    private String vreme;
    private String medjustanice;
    private int brojl;

    public int getBrojl() {
        return brojl;
    }

    public void setBrojl(int brojl) {
        this.brojl = brojl;
    }
    

    public String getPrevoznik() {
        return prevoznik;
    }

    public void setPrevoznik(String prevoznik) {
        this.prevoznik = prevoznik;
    }

    public String getPolazak() {
        return polazak;
    }

    public void setPolazak(String polazak) {
        this.polazak = polazak;
    }

    public String getOdlazak() {
        return odlazak;
    }

    public void setOdlazak(String odlazak) {
        this.odlazak = odlazak;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public String getVreme() {
        return vreme;
    }

    public void setVreme(String vreme) {
        this.vreme = vreme;
    }

    public String getMedjustanice() {
        return medjustanice;
    }

    public void setMedjustanice(String medjustanice) {
        this.medjustanice = medjustanice;
    }
    
}
