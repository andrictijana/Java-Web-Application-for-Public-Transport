/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.sql.Time;
import java.util.Date;
import javax.validation.constraints.Pattern;

/**
 *
 * @author Tijana
 */
public class Gost {
    private String nazivPrevoznika;
    @Pattern(regexp = "(^[0-9][0-9]\\:[0-9][0-9]\\:[0-9][0-9]$)|^$",message="Morate uneti vreme u obliku hh:mm:ss")
    private String od;
    @Pattern(regexp = "(^[0-9][0-9]\\:[0-9][0-9]\\:[0-9][0-9]$)|^$",message="Morate uneti vreme u obliku hh:mm:ss")
    private String doo;
    private String mestoPolazista;
    private String mestoOdredista;
    private Date datum;
    

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }
    

    public String getNazivPrevoznika() {
        return nazivPrevoznika;
    }

    public void setNazivPrevoznika(String nazivPrevoznika) {
        this.nazivPrevoznika = nazivPrevoznika;
    }

    public String getOd() {
        return od;
    }

    public void setOd(String od) {
        this.od = od;
    }

    public String getDoo() {
        return doo;
    }

    public void setDoo(String doo) {
        this.doo = doo;
    }

    public String getMestoPolazista() {
        return mestoPolazista;
    }

    public void setMestoPolazista(String mestoPolazista) {
        this.mestoPolazista = mestoPolazista;
    }

    public String getMestoOdredista() {
        return mestoOdredista;
    }

    public void setMestoOdredista(String mestoOdredista) {
        this.mestoOdredista = mestoOdredista;
    }
    
}
