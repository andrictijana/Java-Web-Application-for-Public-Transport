/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.sql.Time;
import java.util.Date;

/**
 *
 * @author User
 */
public class Stajalista {
    private String ime;
    private int brojlinije;

    private String medjustanice;
    private String vremepolaska;
    private String prevoznik;
    private Date datum;

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }
    

    public String getPrevoznik() {
        return prevoznik;
    }

    public void setPrevoznik(String prevoznik) {
        this.prevoznik = prevoznik;
    }
    

    public String getMedjustanice() {
        return medjustanice;
    }

    public void setMedjustanice(String medjustanice) {
        this.medjustanice = medjustanice;
    }
    
    

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public int getBrojlinije() {
        return brojlinije;
    }

    public void setBrojlinije(int brojlinije) {
        this.brojlinije = brojlinije;
    }



    public String getVremepolaska() {
        return vremepolaska;
    }

    public void setVremepolaska(String vremepolaska) {
        this.vremepolaska = vremepolaska;
    }
    
}
