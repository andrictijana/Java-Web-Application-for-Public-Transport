-- Generation Time: Jun 11, 2018 at 10:42 PM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bas2018`
--
DROP DATABASE IF EXISTS `autobuskastanica`;
CREATE DATABASE IF NOT EXISTS `autobuskastanica`;
USE `autobuskastanica`;



DROP TABLE IF EXISTS Korisnik;
CREATE TABLE IF NOT EXISTS Korisnik (
ime varchar(30)  NOT NULL,
prezime varchar(30)  NOT NULL,
username varchar(30)  NOT NULL ,
password varchar(30)  NOT NULL,
adresa varchar(30)  NOT NULL,
datumRodjenja date  NOT NULL,
telefon varchar(30)  NOT NULL,
zanimanje varchar(30)  NOT NULL,
email varchar(30),
flagReg int,

primary key (`username`)




);

INSERT INTO Korisnik values ('Tijana','Andric','tijana','Sifra123','Breza 11', '1996-11-28','0638786158','student','andrictijana96@gmail.com',0);
INSERT INTO Korisnik values ('Kristina','Andric','kiki','Sifra123','Trgovacka 15', '1995-01-18','0641160093','student','kiki95@gmail.com',0);
INSERT INTO Korisnik values ('Isidora','Reljic','isi','Sifra123','Kneza Milosa 10', '1970-09-07','0646677999','zaposlen','isireljic@gmail.com',0);
INSERT INTO Korisnik values ('Milan','Rakic','milan','Sifra123','Zarkovacka 5', '1980-09-15','0616548666','nezaposlen','milanr@gmail.com',0);
INSERT INTO Korisnik values ('Rade','Korac','rade','Sifra123','Diljska 2', '1956-12-04','0609912356','penzioner','radekorac@gmail.com',0);
INSERT INTO Korisnik values ('Tamara','Marinovic','tamara','Sifra123','Dzona Kenedija 26', '1994-12-25','0667788156','student','takim@gmail.com',1);
INSERT INTO Korisnik values ('Milos','Despotovic','miki','Sifra123','Turgenjeva 35', '1975-02-07','0659786345','zaposlen','mikid75@gmail.com',1);
INSERT INTO Korisnik values ('Nikola','Savkovic','nikola','Sifra123','Ilije Djuricica 12', '1963-05-05','0615566345','nezaposlen','nidzas@gmail.com',1);
INSERT INTO Korisnik values ('Bojan','Vucurevic','bojan','Sifra123','Arcibalda Rajsa 5', '1945-09-16','0634455666','lice sa invaliditetom','bojanvucurevic@gmail.com',1);
INSERT INTO Korisnik values ('Marija','Obradovic','marija','Sifra123','Milutina Milankovica 37', '1998-09-27','0643377888','student','makiobradovic98@gmail.com',1);

  DROP TABLE IF EXISTS Poruka;
 CREATE TABLE IF NOT EXISTS Poruka (
   id int primary key AUTO_INCREMENT,
   uname varchar (30) not null references korisnik on update cascade on delete cascade,
   sadrzaj varchar (200) not null

 
 );

 INSERT INTO Poruka(uname,sadrzaj) values ('admin','Linija 37 nece saobracati u periodu od 22/09/2018 do 27/09/2018 !');
 INSERT INTO Poruka(uname,sadrzaj) values ('admin','Linija 83 nece saobracati u periodu od 01/10/2018 do 07/10/2018 !');


  DROP TABLE IF EXISTS Kartica;
CREATE TABLE IF NOT EXISTS Kartica  (
    vrsta varchar (30) NOT NULL,
	zahtev int,
    uname varchar (30) NOT NULL references korisnik on update cascade on delete cascade,
   
	primary key (uname)
	
  );
  
  INSERT INTO Kartica values ('mesecna',0,'tijana');
  INSERT INTO Kartica values ('godisnja',1,'kiki');
  INSERT INTO Kartica values ('mesecna',0,'isi');
  INSERT INTO Kartica values ('godisnja',1,'rade');
  INSERT INTO Kartica values ('godisnja',1,'milan');

  
  DROP TABLE IF EXISTS CeneKartica;
  CREATE TABLE IF NOT EXISTS CeneKartica(
    
	cena int,
	 zaposlenje varchar(30) NOT NULL,
	primary key (zaposlenje)
  );

DROP TABLE IF EXISTS `glinija`;
CREATE TABLE IF NOT EXISTS `glinija`(
 
  pocetnoOdrediste varchar(50)  NOT NULL,
  krajnjeOdrediste varchar(50) NOT NULL,
  brojLinije varchar(30) NOT NULL,
  redVoznje varchar(150) NOT NULL,
  
  
  PRIMARY KEY (`brojLinije`)
);

INSERT INTO glinija values('Vidikovac', 'Zeleni Venac', 'BGD-53', '4:00, 4:15, 4:30, 4:45, 5:00, 5:15, 5:30, 5:45, 6:00, 7:00, 8:00,9:00, 10:00, 11:00, 12:00,13:00,14:00, 15:00, 16:00, 17:00, 21:00');
INSERT INTO glinija values('Knezevac', 'Pancevacki most', 'BGD-37', '4:00, 4:15, 4:30, 4:45, 5:00, 5:15, 5:30, 5:45, 6:00, 7:00, 8:00,9:00, 10:00, 15:00, 16:00, 21:00');
INSERT INTO glinija values('Banovo Brdo', 'Ustanicka', 'BGD-50', '4:00, 4:15, 4:30, 4:45, 5:00, 5:15, 5:30, 5:45, 6:00, 7:00, 8:00,9:00, 10:00, 11:00, 12:00,13:00,14:00, 15:00, 16:00, 17:00, 21:00');
INSERT INTO glinija values('Novi Zeleznik', 'Kej oslobodjenja', 'BGD-88', '4:00, 4:15, 4:30, 4:45, 5:00, 5:15, 5:30, 5:45, 6:00, 7:00, 8:00,9:00, 10:00, 11:00, 12:00,13:00,14:00, 15:00, 16:00, 17:00, 21:00');
INSERT INTO glinija values('Dorcol', 'Brace Jerkovic', 'BGD-26', '4:00, 4:15, 4:30, 4:45, 5:00, 5:15, 5:30, 5:45, 6:00, 7:00, 8:00,9:00, 10:00, 11:00, 12:00,13:00,14:00, 15:00, 16:00, 17:00, 21:00');
INSERT INTO glinija values('Zeleni Venac', 'Bezanijska kosa', 'BGD-75', '4:00, 4:15, 4:30, 4:45, 5:00, 5:15, 5:30, 5:45, 6:00, 7:00, 8:00,9:00, 10:00, 11:00, 12:00,13:00,14:00, 15:00, 16:00, 17:00, 21:00');
INSERT INTO glinija values('Zeleni Venac', 'Aerodrom "Nikola Tesla"', 'BGD-72', '4:00, 4:15, 4:30, 4:45, 5:00, 5:15, 5:30, 5:45, 6:00, 7:00, 8:00,9:00, 10:00, 11:00, 12:00,13:00,14:00, 15:00, 16:00, 17:00, 21:00');
INSERT INTO glinija values('Usce', 'Kotez', 'BGD-43', '4:00, 4:15, 4:30, 4:45, 5:00, 5:15, 5:30, 5:45, 6:00, 7:00, 8:00,9:00, 10:00, 11:00, 12:00,13:00,14:00, 15:00, 16:00, 17:00, 21:00');
INSERT INTO glinija values('Borca 3', 'Blok 45', 'BGD-95', '4:00, 4:15, 4:30, 4:45, 5:00, 5:15, 5:30, 5:45, 6:00, 7:00, 8:00,9:00, 10:00, 11:00, 12:00,13:00,14:00, 15:00, 16:00, 17:00, 21:00');
INSERT INTO glinija values('Crveni krst', 'Zemun', 'BGD-83', '4:00, 4:15, 4:30, 4:45, 5:00, 5:15, 5:30, 5:45, 6:00, 7:00, 8:00,9:00, 10:00, 11:00, 12:00,13:00,14:00, 15:00, 16:00, 17:00, 21:00');
INSERT INTO glinija values('Konjarnik', 'Zemun', 'BGD-17', '4:00, 4:15, 4:30, 4:45, 5:00, 5:15, 5:30, 5:45, 6:00, 7:00, 8:00,9:00, 10:00, 11:00, 12:00,13:00,14:00, 15:00, 16:00, 17:00, 21:00');
INSERT INTO glinija values('Mirijevo', 'Bezanijska kosa', 'BGD-74', '4:00, 4:15, 4:30, 4:45, 5:00, 5:15, 5:30, 5:45, 6:00, 7:00, 8:00,9:00, 10:00, 11:00, 12:00,13:00,14:00, 15:00, 16:00, 17:00, 21:00');


DROP TABLE IF EXISTS mlinija;
CREATE TABLE IF NOT EXISTS mlinija(

  pocetnoOdrediste varchar(50) NOT NULL,
  krajnjeOdrediste varchar(50) NOT NULL,
  brojLinije int primary key,
 
  vremePolaska time,
  datum date,
  idPrevoznika int NOT NULL REFERENCES Prevoznik ON UPDATE CASCADE ON DELETE CASCADE
  
  
 );
 
INSERT INTO mlinija values ('Beograd','Subotica',1,'09:00:00','2018-9-25',1);
INSERT INTO mlinija values ('Nis','Beograd',2,'12:00:00','2018-9-06',2);
INSERT INTO mlinija values ('Vrsac', 'Sombor',3, '10:00:00','2018-9-07',1);
INSERT INTO mlinija values ('Novi Sad', 'Nis',4, '16:00:00','2018-9-17',2);
INSERT INTO mlinija values ('Smederevo', 'Prizren',5, '08:00:00','2018-9-20',1);
INSERT INTO mlinija values ('Sabac', 'Leskovac',6, '07:30:00','2018-9-24',1);
INSERT INTO mlinija values ('Valjevo', 'Sombor',7, '13:20:00','2018-9-13',1);
INSERT INTO mlinija values ('Beograd', 'Prijepolje',8, '11:30:00','2018-9-12',3);
INSERT INTO mlinija values ('Paracin', 'Pec',9, '06:30:00','2018-9-12',2);
INSERT INTO mlinija values ('Subotica', 'Zrenjanin',10, '21:10:00','2018-9-20',1);
INSERT INTO mlinija values ('Cacak', 'Novi Pazar',11, '20:30:00','2018-9-12',3);


 
  DROP TABLE IF EXISTS Stajaliste;
  CREATE TABLE IF NOT EXISTS Stajaliste(
  k1 double not null,
  k2 double not null,
  redniBroj int not null,
  mesto varchar(30) NOT NULL,
  vremePolaska time,
  brojLinije int not null references mlinija on update cascade on delete cascade,
 
  primary key(brojLinije,redniBroj)
  );
INSERT INTO Stajaliste values (44.786568,20.44892159999995,1,'Beograd','09:00:00',1);  
INSERT INTO Stajaliste values (45.2671352,19.83354959999997,2,'Novi Sad','10:30:00',1);  
INSERT INTO Stajaliste values (45.3815612,20.36857370000007,3,'Zrenjanin','11:00:00',1);  
INSERT INTO Stajaliste values (45.8272842,20.46151729999997,4,'Kikinda','12:00:00',1); 
INSERT INTO Stajaliste values (46.1005467,19.66505929999994,5,'Subotica','13:30:00',1);  
INSERT INTO Stajaliste values (43.3209022,21.895758900000033,1,'Nis','12:00:00',2);  
INSERT INTO Stajaliste values (44.6658941,20.933516899999972,5,'Smederevo','15:40:00',2);
INSERT INTO Stajaliste values (43.97772940000001,21.257271899999978,4,'Jagodina','15:00:00',2);  
INSERT INTO Stajaliste values (43.5763232,21.333581200000026,3,'Krusevac','14:00:00',2);  
INSERT INTO Stajaliste values (43.54099009999999,21.718369499999994,2,'Aleksinac','12:30:00',2);     
INSERT INTO Stajaliste values (44.786568,20.44892159999995,6,'Beograd','16:20:00',2); 
INSERT INTO Stajaliste values (45.1181926,21.294488300000012,1, 'Vrsac', '10:00:00',3);
INSERT INTO Stajaliste values (45.3815612,20.36857370000007,2, 'Zrenjanin', '11:35:00',3);
INSERT INTO Stajaliste values (45.6138162,20.045985299999984,3, 'Becej', '12:40:00',3);
INSERT INTO Stajaliste values (45.8272842,20.46151729999997,4, 'Kikinda', '14:00:00',3);
INSERT INTO Stajaliste values (45.773295,19.115146900000013,5, 'Sombor', '15:45:00',3);
INSERT INTO Stajaliste values (45.2671352,19.83354959999997,1, 'Novi Sad', '16:00:00',4);
INSERT INTO Stajaliste values (44.786568,20.44892159999995,2, 'Beograd', '17:30:00',4);
INSERT INTO Stajaliste values (44.6658941,20.933516899999972,3, 'Smederevo', '18:15:00',4);
INSERT INTO Stajaliste values (43.5763232,21.333581200000026,4, 'Krusevac', '20:20:00',4);
INSERT INTO Stajaliste values (43.3209022,21.895758900000033,5, 'Nis', '21:45:00',4);
INSERT INTO Stajaliste values (44.6658941,20.933516899999972,1, 'Smederevo', '08:00:00',5);
INSERT INTO Stajaliste values (43.8914144,20.350165199999992,2, 'Cacak', '10:15:00',5);
INSERT INTO Stajaliste values (43.85557290000001,19.842470999999932,3, 'Uzice', '11:00:00',5);
INSERT INTO Stajaliste values (43.1406976,20.521361699999943,4, 'Novi Pazar', '14:15:00',5);
INSERT INTO Stajaliste values (42.2152585,20.74147389999996,5, 'Prizren', '16:10:00',5);
INSERT INTO Stajaliste values (44.74886119999999,19.690788200000043,1, 'Sabac', '07:30:00',6);
INSERT INTO Stajaliste values (44.786568,20.44892159999995,2, 'Beograd', '10:30:00',6);
INSERT INTO Stajaliste values (44.6658941,20.933516899999972,3,'Smederevo','11:40:00',6);
INSERT INTO Stajaliste values (43.97772940000001,21.257271899999978,4,'Jagodina','13:00:00',6);  
INSERT INTO Stajaliste values (43.5763232,21.333581200000026,5,'Krusevac','14:10:00',6);
INSERT INTO Stajaliste values (43.3209022,21.895758900000033,6, 'Nis', '15:35:00',6);  
INSERT INTO Stajaliste values (42.9963758,21.944033999999988,7, 'Leskovac', '16:45:00',6);
INSERT INTO Stajaliste values (44.2743141,19.890339799999992,1, 'Valjevo', '13:20:00',7);
INSERT INTO Stajaliste values (44.786568,20.44892159999995,2, 'Beograd', '14:50:00',7);
INSERT INTO Stajaliste values (45.2671352,19.83354959999997,3, 'Novi Sad', '16:20:00',7);
INSERT INTO Stajaliste values (45.773295,19.115146900000013,4, 'Sombor', '18:05:00',7);
INSERT INTO Stajaliste values (44.786568,20.44892159999995,1, 'Beograd', '11:30:00',8);
INSERT INTO Stajaliste values (44.2743141,19.890339799999992,2, 'Valjevo', '13:10:00',8);
INSERT INTO Stajaliste values (43.8914144,20.350165199999992,3, 'Cacak', '14:15:00',8);
INSERT INTO Stajaliste values (43.85557290000001,19.842470999999932,4, 'Uzice', '15:00:00',8);
INSERT INTO Stajaliste values (43.3893574,19.646366599999965,5, 'Prijepolje', '17:15:00',8);
INSERT INTO Stajaliste values (43.858616,21.403910999999994,1, 'Paracin', '06:30:00',9);
INSERT INTO Stajaliste values (43.5763232,21.333581200000026,2,'Krusevac','09:10:00',9);
INSERT INTO Stajaliste values (43.3209022,21.895758900000033,3, 'Nis', '10:35:00',9);  
INSERT INTO Stajaliste values (42.9963758,21.944033999999988,4, 'Leskovac', '11:45:00',9);
INSERT INTO Stajaliste values (42.6629138,21.165502800000013,5, 'Pristina', '12:35:00',9);
INSERT INTO Stajaliste values (42.6592868,20.28873580000004,6, 'Pec', '14:05:00',9);
INSERT INTO Stajaliste values (46.1005467,19.66505929999994,1,'Subotica','21:10:00',10);  
INSERT INTO Stajaliste values (45.8272842,20.46151729999997,2,'Kikinda','22:00:00',10);
INSERT INTO Stajaliste values (45.3815612,20.36857370000007,3,'Zrenjanin','22:50:00',10); 
INSERT INTO Stajaliste values (43.8914144,20.350165199999992,1, 'Cacak', '20:30:00',11);
INSERT INTO Stajaliste values (43.85557290000001,19.842470999999932,2, 'Uzice', '21:00:00',11);
INSERT INTO Stajaliste values (43.1406976,20.521361699999943,3, 'Novi Pazar', '21:55:00',11);

  
  DROP TABLE IF EXISTS gStanica;
CREATE TABLE IF NOT EXISTS gStanica (
redniBroj int not null,
  mesto varchar(30) NOT NULL,
  brojLinije varchar (30) not  null references glinija on update cascade on delete cascade,
  
  
 
  primary key(brojLinije,redniBroj)
);

INSERT INTO gStanica values (1,'Vidikovac','BGD-53');
INSERT INTO gStanica values (2,'Pilota Mihajla Petrovica','BGD-53');
INSERT INTO gStanica values (3,'Skojevsko naselje','BGD-53');
INSERT INTO gStanica values (4,'Kosutnjak','BGD-53');
INSERT INTO gStanica values (5,'Kijevska','BGD-53');
INSERT INTO gStanica values (6,'Ada Ciganlija','BGD-53');
INSERT INTO gStanica values (7,'Ruska','BGD-53');
INSERT INTO gStanica values (8,'Sajam','BGD-53');
INSERT INTO gStanica values (9,'Sarajevska','BGD-53');
INSERT INTO gStanica values (10,'Zeleni Venac','BGD-53');
INSERT INTO gStanica values (1,'Knezevac','BGD-37');
INSERT INTO gStanica values (2,'Opstina Rakovica','BGD-37');
INSERT INTO gStanica values (3,'Maricka','BGD-37');
INSERT INTO gStanica values (4,'Pilota Mihajla Petrovica','BGD-37');
INSERT INTO gStanica values (5,'Filmski grad','BGD-37');
INSERT INTO gStanica values (6,'Zarkovo','BGD-37');
INSERT INTO gStanica values (7,'Kijevska','BGD-37');
INSERT INTO gStanica values (8,'Ruska','BGD-37');
INSERT INTO gStanica values (9,'Sajam','BGD-37');
INSERT INTO gStanica values (10,'Kneza Milosa','BGD-37');
INSERT INTO gStanica values (11,'Trg Republike','BGD-37');
INSERT INTO gStanica values (12,'Pancevacki most','BGD-37');
INSERT INTO gStanica values (1,'Banovo brdo','BGD-50');
INSERT INTO gStanica values (2,'Zarkovo','BGD-50');
INSERT INTO gStanica values (3,'Filmski grad','BGD-50');
INSERT INTO gStanica values (4,'Pilota Mihajla Petrovica','BGD-50');
INSERT INTO gStanica values (5,'Maricka','BGD-50');
INSERT INTO gStanica values (6,'Opstina Rakovica','BGD-50');
INSERT INTO gStanica values (7,'Kanarevo Brdo','BGD-50');
INSERT INTO gStanica values (8,'Pet Solitera','BGD-50');
INSERT INTO gStanica values (9,'Sumice','BGD-50');
INSERT INTO gStanica values (10,'Konjarnik','BGD-50');
INSERT INTO gStanica values (11,'Ustanicka','BGD-50');
INSERT INTO gStanica values (1,'Novi Zeleznik','BGD-88');
INSERT INTO gStanica values (2,'Lole Ribara','BGD-88');
INSERT INTO gStanica values (3,'Bele vode','BGD-88');
INSERT INTO gStanica values (4,'Ilije Djuricica','BGD-88');
INSERT INTO gStanica values (5,'Trebevicka','BGD-88');
INSERT INTO gStanica values (6,'Kijevska','BGD-88');
INSERT INTO gStanica values (7,'Ada Ciganlija','BGD-88');
INSERT INTO gStanica values (8,'Sajam','BGD-88');
INSERT INTO gStanica values (9,'Sava Centar','BGD-88');
INSERT INTO gStanica values (10,'Beogradska arena','BGD-88');
INSERT INTO gStanica values (11,'Bulevar Zorana Djindjica','BGD-88');
INSERT INTO gStanica values (12,'Dzona Kenedija','BGD-88');
INSERT INTO gStanica values (13,'Kej oslobodjenja','BGD-88');
INSERT INTO gStanica values (1,'Dorcol','BGD-26');
INSERT INTO gStanica values (2,'Trg Republike','BGD-26');
INSERT INTO gStanica values (3,'Resavska','BGD-26');
INSERT INTO gStanica values (4,'Pravni fakultet','BGD-26');
INSERT INTO gStanica values (5,'Tehnicki fakulteti','BGD-26');
INSERT INTO gStanica values (6,'Juzni bulevar','BGD-26');
INSERT INTO gStanica values (7,'Dusanovac','BGD-26');
INSERT INTO gStanica values (8,'Brace Jerkovic','BGD-26');
INSERT INTO gStanica values (1,'Zeleni Venac','BGD-75');
INSERT INTO gStanica values (2,'Brankov most','BGD-75');
INSERT INTO gStanica values (3,'Usce','BGD-75');
INSERT INTO gStanica values (4,'Blok 30','BGD-75');
INSERT INTO gStanica values (5,'Ulaz u pariske komune','BGD-75');
INSERT INTO gStanica values (6,'Fontana','BGD-75');
INSERT INTO gStanica values (7,'Studentska','BGD-75');
INSERT INTO gStanica values (8,'Bezanijska kosa','BGD-75');
INSERT INTO gStanica values (1,'Zeleni Venac','BGD-72');
INSERT INTO gStanica values (2,'Brankov most','BGD-72');
INSERT INTO gStanica values (3,'Usce','BGD-72');
INSERT INTO gStanica values (4,'Palata Srbija','BGD-72');
INSERT INTO gStanica values (5,'Blok 30','BGD-72');
INSERT INTO gStanica values (6,'Ulaz u pariske komune','BGD-72');
INSERT INTO gStanica values (7,'Fontana','BGD-72');
INSERT INTO gStanica values (8,'Studentska','BGD-72');
INSERT INTO gStanica values (9,'Tosin bunar','BGD-72');
INSERT INTO gStanica values (10,'Aerodrom "Nikola Tesla"','BGD-75');
INSERT INTO gStanica values (1,'Usce','BGD-43');
INSERT INTO gStanica values (2,'Zeleznicka stanica','BGD-43');
INSERT INTO gStanica values (3,'Karaburma','BGD-43');
INSERT INTO gStanica values (4,'Dusanovac','BGD-43');
INSERT INTO gStanica values (5,'Konjarnik','BGD-43');
INSERT INTO gStanica values (6,'Ustanicka','BGD-43');
INSERT INTO gStanica values (7,'Kotez','BGD-43');
INSERT INTO gStanica values (1,'Borca 3','BGD-95');
INSERT INTO gStanica values (2,'Zemunska','BGD-95');
INSERT INTO gStanica values (3,'Zeleni Venac','BGD-95');
INSERT INTO gStanica values (4,'Brankov most','BGD-95');
INSERT INTO gStanica values (5,'Usce','BGD-95');
INSERT INTO gStanica values (6,'Milutina Milankovica','BGD-95');
INSERT INTO gStanica values (7,'Naselje Belvil','BGD-95');
INSERT INTO gStanica values (8,'Blok 70','BGD-95');
INSERT INTO gStanica values (9,'Borca 45','BGD-95');
INSERT INTO gStanica values (1,'Crveni krst','BGD-83');
INSERT INTO gStanica values (2,'Dusanovac','BGD-83');
INSERT INTO gStanica values (3,'Hram','BGD-83');
INSERT INTO gStanica values (4,'Slavija','BGD-83');
INSERT INTO gStanica values (5,'Nemanjina','BGD-83');
INSERT INTO gStanica values (6,'Zeleznicka stanica','BGD-83');
INSERT INTO gStanica values (7,'Usce','BGD-83');
INSERT INTO gStanica values (8,'Bulevar Zorana Djindjica','BGD-83');
INSERT INTO gStanica values (9,'Dzona Kenedija','BGD-83');
INSERT INTO gStanica values (10,'Zemun','BGD-83');
INSERT INTO gStanica values (1,'Konjarnik','BGD-17');
INSERT INTO gStanica values (2,'Autokomanda','BGD-17');
INSERT INTO gStanica values (3,'Juzni Bulevar','BGD-17');
INSERT INTO gStanica values (4,'Mostar','BGD-17');
INSERT INTO gStanica values (5,'Sava centar','BGD-17');
INSERT INTO gStanica values (6,'Beogradska arena','BGD-17');
INSERT INTO gStanica values (7,'Bulevar Zorana Djindjica','BGD-17');
INSERT INTO gStanica values (8,'Dzona Kenedija','BGD-17');
INSERT INTO gStanica values (9,'Zemun','BGD-17');
INSERT INTO gStanica values (1,'Mirijevo','BGD-74');
INSERT INTO gStanica values (2,'Diljska','BGD-74');
INSERT INTO gStanica values (3,'Ruzveltova','BGD-74');
INSERT INTO gStanica values (4,'Tehnicki fakulteti','BGD-74');
INSERT INTO gStanica values (5,'Pravni fakultet','BGD-74');
INSERT INTO gStanica values (6,'Kneza Milosa','BGD-74');
INSERT INTO gStanica values (7,'Sava centar','BGD-74');
INSERT INTO gStanica values (8,'Beogradska arena','BGD-74');
INSERT INTO gStanica values (9,'Bulevar umetnosti','BGD-74');
INSERT INTO gStanica values (10,'Studentska','BGD-74');
INSERT INTO gStanica values (11,'Bezanijska kosa','BGD-74');



DROP TABLE IF EXISTS Vozac;
CREATE TABLE IF NOT EXISTS Vozac(
id int AUTO_INCREMENT,
ime varchar(30)  NOT NULL,
prezime varchar(30)  NOT NULL,
datumRodjenja date  NOT NULL,
godinaPocetka int NOT NULL,

primary key (`id`)

);

INSERT INTO Vozac(ime,prezime,datumRodjenja,godinaPocetka) values ('Branko','Brankovic', '1962-10-12','1995');
INSERT INTO Vozac(ime,prezime,datumRodjenja,godinaPocetka) values ('Milan','Milojevic', '1980-06-25','2010');
INSERT INTO Vozac(ime,prezime,datumRodjenja,godinaPocetka) values ('Djura','Djuric', '1976-07-07','2015');
INSERT INTO Vozac(ime,prezime,datumRodjenja,godinaPocetka) values ('Pavle','Pavlovic', '1970-12-12','2004');
INSERT INTO Vozac(ime,prezime,datumRodjenja,godinaPocetka) values ('Bojan','Bojic', '1967-11-12','2002');
INSERT INTO Vozac(ime,prezime,datumRodjenja,godinaPocetka) values ('Zoran','Zoric', '1956-08-06','1996');
INSERT INTO Vozac(ime,prezime,datumRodjenja,godinaPocetka) values ('Dimitrije','Dimic', '1972-12-04','2016');
INSERT INTO Vozac(ime,prezime,datumRodjenja,godinaPocetka) values ('Nemanja','Nemanjic', '1961-05-21','2000');
INSERT INTO Vozac(ime,prezime,datumRodjenja,godinaPocetka) values ('Aleksandar','Aleksic', '1968-08-08','2012');
INSERT INTO Vozac(ime,prezime,datumRodjenja,godinaPocetka) values ('Milos','Milosevic', '1960-03-12','1995');
INSERT INTO Vozac(ime,prezime,datumRodjenja,godinaPocetka) values ('Nikola','Nikolic', '1968-11-20','2001');

DROP TABLE IF EXISTS GVozac;
CREATE TABLE IF NOT EXISTS GVozac(
idVozaca int NOT NULL REFERENCES vozac ON UPDATE CASCADE ON DELETE CASCADE,
brojLinije varchar(30)  NOT NULL REFERENCES glinija ON UPDATE CASCADE ON DELETE CASCADE,

PRIMARY KEY(brojLinije,idVozaca)
);

INSERT INTO GVozac values(1,'BGD-37');
INSERT INTO GVozac values(2,'BGD-37');
INSERT INTO GVozac values(3,'BGD-50');
INSERT INTO GVozac values(4,'BGD-53');
INSERT INTO GVozac values(5,'BGD-88');
INSERT INTO GVozac values(6,'BGD-95');
INSERT INTO GVozac values(7,'BGD-43');
INSERT INTO GVozac values(8,'BGD-75');
INSERT INTO GVozac values(9,'BGD-72');
INSERT INTO GVozac values(10,'BGD-83');
INSERT INTO GVozac values(11,'BGD-17');
INSERT INTO GVozac values(4,'BGD-74');
INSERT INTO GVozac values(5,'BGD-95');
INSERT INTO GVozac values(6,'BGD-83');
INSERT INTO GVozac values(7,'BGD-74');

  DROP TABLE IF EXISTS MVozac;
  CREATE TABLE IF NOT EXISTS MVozac (
  idVozaca int not NULL References Vozac on update cascade on delete cascade,
  brojLinije int NOT NULL REFERENCES mlinija on update cascade on delete cascade,
  datum date not NULL,
  primary key(brojLinije,idVozaca,datum)
  );
  
  INSERT INTO MVozac values (1,1,'2018-09-25');
  INSERT INTO MVozac values (2,2,'2018-09-06');
  INSERT INTO MVozac values (3,3,'2018-09-07');
  INSERT INTO MVozac values (4,4,'2018-9-17');
  INSERT INTO MVozac values (5,5,'2018-9-20');
  INSERT INTO MVozac values (6,6,'2018-9-24');
  INSERT INTO MVozac values (7,7,'2018-9-13');
  INSERT INTO MVozac values (8,8,'2018-9-12');
  INSERT INTO MVozac values (9,9,'2018-9-12');
  INSERT INTO MVozac values (10,10,'2018-9-20');
  INSERT INTO MVozac values (11,11,'2018-9-12');
  
  DROP TABLE IF EXISTS Autobus;
  CREATE TABLE IF NOT EXISTS Autobus (
  id int primary key AUTO_INCREMENT,
 
  model varchar (30) NOT NULL,
  marka varchar (30) NOT NULL,
  kapacitet int NOT NULL
   
  );
  
  INSERT INTO Autobus (model,marka,kapacitet) values ('M1','Mercedes',130);
  INSERT INTO Autobus (model,marka,kapacitet) values ('S1','Solaris',75);
  INSERT INTO Autobus (model,marka,kapacitet) values ('M1','Mercedes',90);

  DROP TABLE IF EXISTS Slika;
  CREATE TABLE IF NOT EXISTS Slika (
  redniBroj int not null check (redniBroj between 1 and 5),
  slika varchar(50) not null,
 idBusa int not null references Autobus on update cascade on delete cascade,
  primary key (idBusa,redniBroj)
  );
  
  INSERT INTO Slika values (1,'lasta1.jpg',1);
  INSERT INTO Slika values (2,'lasta2.jpg',1);
  INSERT INTO Slika values (3,'lasta3.jpg',1);
  INSERT INTO Slika values (4,'lasta4.jpg',1);
  INSERT INTO Slika values (1,'nis1.jpg',2);
  INSERT INTO Slika values (2,'nis2.jpg',2);  
  INSERT INTO Slika values (3,'nis3.jpg',2); 
  INSERT INTO Slika values (1,'gaga1.jpg',3);
  INSERT INTO Slika values (2,'gaga2.jpg',3);  
  INSERT INTO Slika values (3,'gaga3.jpg',3);    
  
  DROP TABLE IF EXISTS MAutobus;
  CREATE TABLE IF NOT EXISTS MAutobus (
  idB int not NULL References Autobus on update cascade on delete cascade,
  brojLinije int NOT NULL REFERENCES mlinija on update cascade on delete cascade,
  datum date not NULL,
  primary key(brojLinije,idB,datum)
  );
  
  INSERT INTO MAutobus values (1,1,'2018-9-25');
  INSERT INTO MAutobus values (2,2,'2018-9-06');
  INSERT INTO MAutobus values (1,3,'2018-9-07');
  INSERT INTO MAutobus values (2,4,'2018-9-17');
  INSERT INTO MAutobus values (1,5,'2018-9-20');
  INSERT INTO MAutobus values (1,6,'2018-9-24');
  INSERT INTO MAutobus values (1,7,'2018-9-13');
  INSERT INTO MAutobus values (3,8,'2018-9-12');
  INSERT INTO MAutobus values (2,9,'2018-9-12');
  INSERT INTO MAutobus values (1,10,'2018-9-20');
  INSERT INTO MAutobus values (3,11,'2018-9-12');
  
    DROP TABLE  IF EXISTS Prevoznik;
 CREATE TABLE IF NOT EXISTS Prevoznik (
 idPrevoznika int primary key AUTO_INCREMENT,
 logo varchar (50),
 naziv varchar(30) NOT NULL,
 adresa varchar(30) NOT NULL,
 telefon varchar(30) NOT NULL
 );
 
 INSERT INTO Prevoznik (logo,naziv,adresa,telefon) values ('Lasta.jpg','Lasta','Zemunska 15','063555333');
 INSERT INTO Prevoznik (naziv,adresa,telefon) values ('NisExpress','Trgovacka 10','0647865444');
 INSERT INTO Prevoznik (naziv,adresa,telefon) values ('Gaga Turs','Pozeska 2','0612277555');
 
  
  DROP TABLE IF EXISTS VecRezKarte;
  CREATE TABLE IF NOT EXISTS VecRezKarte (
  brojLinije int not NULL references mlinija on update cascade on delete cascade,
  datum date not null,
  broj int,
  
  primary key (brojLinije,datum)
  );
  
  INSERT INTO VecRezKarte values (1,'2018-09-25',80);
  INSERT INTO VecRezKarte values (2,'2018-9-06',75);
  
  DROP TABLE IF EXISTS Rezervacija;
  CREATE TABLE IF NOT EXISTS Rezervacija (
  brojLinije int not NUll references mlinija on update cascade on delete cascade,
  uname varchar (30) NOT NULL references korisnik on update cascade on delete cascade,
  datum date not null,
  broj int not null,
  zahtev int,
  primary key(uname,brojLinije,datum)
  
  );
  
  INSERT INTO Rezervacija values(2,'tijana','2018-9-06',1,1);
  INSERT INTO Rezervacija values(1,'tijana','2018-09-25',1,1);
  INSERT INTO Rezervacija values(3,'milan','2018-9-07',1,1);
  INSERT INTO Rezervacija values(1,'kiki','2018-09-25',1,1);
  INSERT INTO Rezervacija values(4,'isi','2018-9-17',1,0);
  
